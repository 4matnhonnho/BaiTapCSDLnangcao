CREATE TABLE Hang (
    Mahang VARCHAR2(5) PRIMARY KEY, 
    Tenhang VARCHAR2(50) NOT NULL, 
    Soluong NUMBER(10),
    Giaban NUMBER(15,2)
);

CREATE TABLE Hoadon (
    Mahd VARCHAR2(5) PRIMARY KEY,
    Mahang VARCHAR2(5) REFERENCES Hang(Mahang),
    Soluongban NUMBER(10),
    Ngayban DATE
);

-- Phieu 1 cau 1

CREATE OR REPLACE TRIGGER TRG_HOADON_INSERT
BEFORE INSERT ON Hoadon
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
    v_tonkho NUMBER := 0;
BEGIN 
    SELECT COUNT(*) INTO v_dem FROM Hang WHERE Mahang = :NEW.Mahang;
    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Ma hang khong ton tai'); 
    END IF;
    SELECT Soluong INTO v_tonkho FROM Hang WHERE Mahang = :NEW.Mahang;
    IF :NEW.Soluongban > v_tonkho THEN
        RAISE_APPLICATION_ERROR(-20001, 'So luong ban vuot qua so luong ton kho'); 
    END IF;
    UPDATE Hang
    SET Soluong = Soluong - :NEW.Soluongban
    WHERE Mahang = :NEW.Mahang;
END;
/

INSERT INTO Hoadon VALUES ('HD01', '1', 5, TO_DATE('01-01-2024', 'dd-mm-yyyy'));

INSERT INTO Hang VALUES ('1', 'Hang A', 5, 100000);
INSERT INTO Hang VALUES ('2', 'Hang B', 10, 150000);
INSERT INTO Hang VALUES ('3', 'Hang C', 20, 200000);
COMMIT;

INSERT INTO Hoadon VALUES ('HD01', '3', 2, TO_DATE('01-01-2024', 'dd-mm-yyyy'));

-- Phieu 1 b�i 2

CREATE OR REPLACE TRIGGER trg_hoadon_delete
AFTER DELETE ON Hoadon
FOR EACH ROW
BEGIN
    UPDATE Hang
    SET Soluong = Soluong + :OLD.Soluongban
    WHERE Mahang = :OLD.Mahang;
END;
/

DELETE FROM Hoadon WHERE Mahd = 'HD01';

select * from hang;

-- Phieu 1 b�i 3

CREATE OR REPLACE TRIGGER trg_hoadon_update
BEFORE UPDATE ON Hoadon
FOR EACH ROW
BEGIN
    UPDATE Hang
    SET Soluong = Soluong - (:NEW.Soluongban - :OLD.Soluongban)
    WHERE Mahang = :NEW.Mahang;
END;
/

UPDATE Hoadon 
SET Soluongban = 8
WHERE Mahd = 'HD01';

-- Phieu BT2

CREATE TABLE Mathang (
    Mahang VARCHAR2(5) CONSTRAINT pk_mathang PRIMARY KEY,
    Tenhang VARCHAR2(50) NOT NULL,
    Soluong NUMBER(10)
);

CREATE TABLE Nhatkybanhang (
    Stt NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    Ngay DATE,
    Nguoimua VARCHAR2(50),
    Mahang VARCHAR2(5) REFERENCES Mathang(Mahang),
    Soluong NUMBER(10),
    Giaban NUMBER(15,2)
);

INSERT INTO Mathang VALUES ('1', 'Hang A', 100);
INSERT INTO Mathang VALUES ('2', 'Hang B', 200);
INSERT INTO Mathang VALUES ('3', 'Hang C', 150);
COMMIT;

-- Phieu 2 c�u a

CREATE OR REPLACE TRIGGER trg_nhatkybanhang_insert
AFTER INSERT ON Nhatkybanhang
FOR EACH ROW
BEGIN
    UPDATE Mathang
    SET Soluong = Soluong - :NEW.Soluong
    WHERE Mahang = :NEW.Mahang;
END;
/

INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
VALUES (SYSDATE, 'Nguyen Van A', '1', 10, 50000);

SELECT * FROM Mathang WHERE Mahang = '1';

-- Phieu 2 cau b

CREATE OR REPLACE TRIGGER trg_nhatkybanhang_update_soluong
AFTER UPDATE OF Soluong ON Nhatkybanhang
FOR EACH ROW
BEGIN
    UPDATE Mathang
    SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
    WHERE Mahang = :NEW.Mahang;
END;
/

UPDATE Nhatkybanhang SET Soluong = 15 WHERE Stt = 1;

SELECT * FROM Mathang WHERE Mahang = '1';

-- Phieu 2 cau c

DROP TRIGGER trg_nhatkybanhang_insert;

CREATE OR REPLACE TRIGGER trg_kiemtra_insert
BEFORE INSERT ON Nhatkybanhang
FOR EACH ROW
DECLARE
    v_tonkho NUMBER := 0;
BEGIN
    SELECT Soluong INTO v_tonkho FROM Mathang WHERE Mahang = :NEW.Mahang;
    IF :NEW.Soluong > v_tonkho THEN
        RAISE_APPLICATION_ERROR(-20001, 'So luong ban vuot qua so luong ton kho');
    ELSE
        UPDATE Mathang
        SET Soluong = Soluong - :NEW.Soluong
        WHERE Mahang = :NEW.Mahang;
    END IF;
END;
/

INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
VALUES (SYSDATE, 'Nguyen Van A', '3', 10, 70000);
SELECT * FROM Mathang WHERE Mahang = '3';

INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
VALUES (SYSDATE, 'Nguyen Van B', '2', 500, 60000);

-- Phieu 2 cau d

CREATE OR REPLACE PACKAGE pkg_state_update AS
    g_row_count NUMBER := 0;
END pkg_state_update;
/
CREATE OR REPLACE TRIGGER trg_nhatkybanhang_update_d
FOR UPDATE ON Nhatkybanhang
COMPOUND TRIGGER
    BEFORE STATEMENT IS
    BEGIN
        pkg_state_update.g_row_count := 0;
    END BEFORE STATEMENT;
    BEFORE EACH ROW IS
    BEGIN
        pkg_state_update.g_row_count := pkg_state_update.g_row_count + 1;
        IF pkg_state_update.g_row_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Chi duoc cap nhat 1 dong');
        END IF;
        UPDATE Mathang
        SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
        WHERE Mahang = :NEW.Mahang;
    END BEFORE EACH ROW;
END trg_nhatkybanhang_update_d;
/

INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
VALUES (SYSDATE, 'Khach Hang 1', '1', 5, 50000);
INSERT INTO Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
VALUES (SYSDATE, 'Khach Hang 2', '2', 10, 60000);
COMMIT;

UPDATE Nhatkybanhang 
SET Soluong = 12 
WHERE Stt = 2;

UPDATE Nhatkybanhang 
SET Soluong = 12;

-- Phieu 2 cau e

CREATE OR REPLACE TRIGGER trg_nhatkybanhang_delete_e
FOR DELETE ON Nhatkybanhang
COMPOUND TRIGGER
    BEFORE STATEMENT IS
    BEGIN
        pkg_state_update.g_row_count := 0;
    END BEFORE STATEMENT;
    BEFORE EACH ROW IS
    BEGIN
        pkg_state_update.g_row_count := pkg_state_update.g_row_count + 1;
        IF pkg_state_update.g_row_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Chi duoc xoa 1 dong');
        END IF;
        UPDATE Mathang
        SET Soluong = Soluong + :OLD.Soluong
        WHERE Mahang = :OLD.Mahang;
    END BEFORE EACH ROW;
END trg_nhatkybanhang_delete_e;
/

DELETE FROM Nhatkybanhang;

DELETE FROM Nhatkybanhang
Where Stt=2;

-- Phieu 2 cau g

SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE pr_xoa_mathang (
    p_mahang IN VARCHAR2 
) AS
    v_dem NUMBER := 0; 
BEGIN
    SELECT COUNT(*) INTO v_dem 
    FROM Mathang 
    WHERE Mahang = p_mahang;
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ma hang ' || p_mahang || ' khong ton tai trong he thong.');
    ELSE
        DELETE FROM Nhatkybanhang WHERE Mahang = p_mahang;
        DELETE FROM Mathang WHERE Mahang = p_mahang;
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Da xoa thanh cong mat hang: ' || p_mahang);
    END IF;
END;
/

BEGIN
    pr_xoa_mathang('3');
END;
/

BEGIN
    pr_xoa_mathang('4');
END;
/


-- Phieeu 2 cau h

CREATE OR REPLACE FUNCTION fn_TongTien (
    p_tenhang IN VARCHAR2
) RETURN NUMBER AS
    v_tong NUMBER := 0;
BEGIN
    SELECT SUM(nk.Soluong * nk.Giaban) INTO v_tong
    FROM Nhatkybanhang nk
    JOIN Mathang mh ON nk.Mahang = mh.Mahang
    WHERE mh.Tenhang = p_tenhang;  
    RETURN NVL(v_tong, 0);
END fn_TongTien;
/

SELECT fn_TongTien('Hang A') AS Tong_Doanh_Thu FROM DUAL;

