CREATE TABLE HangSX ( 
 MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY, 
 TenHang VARCHAR2(30) NOT NULL, 
 DiaChi VARCHAR2(50), 
 SoDT VARCHAR2(15),
 Email VARCHAR2(50) 
); 
CREATE TABLE SanPham ( 
 MaSP VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY, 
 MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX), 
 TenSP VARCHAR2(50) NOT NULL, 
 SoLuong NUMBER(10), 
 MauSac VARCHAR2(20), 
 GiaBan NUMBER(15,2), 
 DonViTinh VARCHAR2(15), 
 MoTa CLOB 
); 
CREATE TABLE NhanVien ( 
 MaNV VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY, 
 TenNV VARCHAR2(50) NOT NULL, 
 GioiTinh VARCHAR2(10), 
 DiaChi VARCHAR2(100), 
 SoDT VARCHAR2(15), 
 Email VARCHAR2(50), 
 TenPhong VARCHAR2(30) 
); 
CREATE TABLE PNhap ( 
 SoHDN VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY, 
 NgayNhap DATE, 
 MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV) 
); 
CREATE TABLE Nhap ( 
 SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN), 
 MaSP VARCHAR2(10) REFERENCES SanPham(MaSP), 
 SoLuongN NUMBER(10), 
 DonGiaN NUMBER(15,2), 
 CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP) 
); 
CREATE TABLE PXuat ( 
 SoHDX VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY, 
 NgayXuat DATE, 
 MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV) 
); 
CREATE TABLE Xuat ( 
 SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX), 
 MaSP VARCHAR2(10) REFERENCES SanPham(MaSP), 
 SoLuongX NUMBER(10), 
 CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP) 
);

-- Phieu 1 cau a

CREATE OR REPLACE PROCEDURE sp_NhapHangSX(
    p_MaHangSX VARCHAR2,
    p_TenHang  VARCHAR2,
    p_DiaChi   VARCHAR2,
    p_SoDT     VARCHAR2,
    p_Email    VARCHAR2
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_count
    FROM HangSX
    WHERE TenHang = p_TenHang;
    IF v_count > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten hang da ton tai');
    ELSE
        INSERT INTO HangSX(MaHangSX, TenHang, DiaChi, SoDT, Email)
        VALUES (p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);
        DBMS_OUTPUT.PUT_LINE('Them hang san xuat thanh cong');
    END IF;
    COMMIT;
END;
/

SET SERVEROUTPUT ON;

BEGIN
    sp_NhapHangSX('HangSX01','Samsung','Korea','0123456789','ss@gmail.com');
END;
/
BEGIN
    sp_NhapHangSX('HangSX02','Samsung','China','0234567891','xx@gmail.com');
END;
/

-- Phieu 1 cau b

CREATE OR REPLACE PROCEDURE sp_NhapSP(
    p_MaSP VARCHAR2,
    p_TenHang VARCHAR2,
    p_TenSP VARCHAR2,
    p_SoLuong NUMBER,
    p_MauSac VARCHAR2,
    p_GiaBan NUMBER,
    p_DonViTinh VARCHAR2,
    p_MoTa CLOB
)
AS
    v_MaHangSX VARCHAR2(10);
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM HangSX
    WHERE TenHang = p_TenHang;
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten hang khong ton tai');
        RETURN;
    END IF;
    SELECT MaHangSX INTO v_MaHangSX
    FROM HangSX
    WHERE TenHang = p_TenHang;
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_MaSP;
    IF v_count > 0 THEN
        UPDATE SanPham
        SET TenSP = p_TenSP,
            SoLuong = p_SoLuong,
            MauSac = p_MauSac,
            GiaBan = p_GiaBan,
            DonViTinh = p_DonViTinh,
            MoTa = p_MoTa,
            MaHangSX = v_MaHangSX
        WHERE MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Cap nhat san pham');
    ELSE
        INSERT INTO SanPham
        VALUES(p_MaSP, v_MaHangSX, p_TenSP, p_SoLuong,
               p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);
        DBMS_OUTPUT.PUT_LINE('Them san pham moi');
    END IF;
    COMMIT;
END;
/

BEGIN
    sp_NhapSP('SP01','Hang0tontai','Laptop A',10,'Den',15000000,'Cai','Mo ta');
END;
/

BEGIN
    sp_NhapSP('SP01','Samsung','Laptop A',20,'Trang',16000000,'Cai','Cap nhat thong tin');
END;
/

BEGIN
    sp_NhapSP('SP01','Samsung','Laptop Moi',15,'Xam',14000000,'Cai','sanphammoi');
END;
/

-- Phieu 1 cau c

CREATE OR REPLACE PROCEDURE sp_xoaHangSX(
    p_TenHang VARCHAR2
)
AS
    v_dem NUMBER;
    v_MaHangSX VARCHAR2(10);
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM HangSX
    WHERE TenHang = p_TenHang;
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten hang khong ton tai');
    ELSE
        SELECT MaHangSX INTO v_MaHangSX
        FROM HangSX
        WHERE TenHang = p_TenHang;
        DELETE FROM SanPham
        WHERE MaHangSX = v_MaHangSX;
        DELETE FROM HangSX
        WHERE MaHangSX = v_MaHangSX;
        DBMS_OUTPUT.PUT_LINE('Da xoa hang san xuat');
        COMMIT;
    END IF;
END;
/

BEGIN
sp_xoaHangSX('Samsung');
END;
/

BEGIN
sp_xoaHangSX('HangKhongCo');
END;
/

-- Phieu 1 cau d

CREATE OR REPLACE PROCEDURE sp_NhapNhanVien(
    p_MaNV VARCHAR2,
    p_TenNV VARCHAR2,
    p_GioiTinh VARCHAR2,
    p_DiaChi VARCHAR2,
    p_SoDT VARCHAR2,
    p_Email VARCHAR2,
    p_TenPhong VARCHAR2,
    p_Flag NUMBER
)
AS
BEGIN
    IF p_Flag = 0 THEN
        UPDATE NhanVien
        SET TenNV = p_TenNV,
            GioiTinh = p_GioiTinh,
            DiaChi = p_DiaChi,
            SoDT = p_SoDT,
            Email = p_Email,
            TenPhong = p_TenPhong
        WHERE MaNV = p_MaNV;
        DBMS_OUTPUT.PUT_LINE('Da cap nhat nhan vien');
    ELSE
        INSERT INTO NhanVien
        VALUES(p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi,
               p_SoDT, p_Email, p_TenPhong);
        DBMS_OUTPUT.PUT_LINE('Da them nhan vien');
    END IF;
    COMMIT;
END;
/
BEGIN
sp_NhapNhanVien('NV01','Nguyen Van A','Nam','HCM','0901234567','a@gmail.com','KeToan',1);
END;
/


BEGIN
sp_NhapNhanVien('NV01','Nguyen Van A','Nam','Ha Noi','0909999999','a_new@gmail.com','NhanSu',0);
END;
/

-- Phieu 1 cau e

CREATE OR REPLACE PROCEDURE sp_NhapNhap(
    p_SoHDN VARCHAR2,
    p_MaSP VARCHAR2,
    p_MaNV VARCHAR2,
    p_NgayNhap DATE,
    p_SoLuongN NUMBER,
    p_DonGiaN NUMBER
)
AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaSP khong ton tai');
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_dem
    FROM NhanVien
    WHERE MaNV = p_MaNV;
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaNV khong ton tai');
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_dem
    FROM PNhap
    WHERE SoHDN = p_SoHDN;
    IF v_dem > 0 THEN
        UPDATE Nhap
        SET SoLuongN = p_SoLuongN,
            DonGiaN = p_DonGiaN
        WHERE SoHDN = p_SoHDN
        AND MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Da cap nhat phieu nhap');
    ELSE
        INSERT INTO PNhap
        VALUES(p_SoHDN, p_NgayNhap, p_MaNV);
        INSERT INTO Nhap
        VALUES(p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);
        DBMS_OUTPUT.PUT_LINE('Da them phieu nhap');
    END IF;
    COMMIT;
END;
/

BEGIN
sp_NhapNhap('HDN01','SP_KhongCo','NV01',SYSDATE,10,5000000);
END;
/

BEGIN
sp_NhapNhap('HDN01','SP01','NV_KhongCo',SYSDATE,10,5000000);
END;
/

BEGIN
sp_NhapNhap('HDN01','SP01','NV01',SYSDATE,10,5000000);
END;
/

BEGIN
sp_NhapNhap('HDN01','SP01','NV01',SYSDATE,20,5500000);
END;
/

-- Phieu 1 cau f

CREATE OR REPLACE PROCEDURE sp_NhapXuat(
    p_SoHDX VARCHAR2,
    p_MaSP VARCHAR2,
    p_MaNV VARCHAR2,
    p_NgayXuat DATE,
    p_SoLuongX NUMBER
)
AS
    v_dem NUMBER;
    v_SoLuong NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = p_MaSP;
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaSP khong ton tai');
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_dem
    FROM NhanVien
    WHERE MaNV = p_MaNV;
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaNV khong ton tai');
        RETURN;
    END IF;
    SELECT SoLuong INTO v_SoLuong
    FROM SanPham
    WHERE MaSP = p_MaSP;
    IF p_SoLuongX > v_SoLuong THEN
        DBMS_OUTPUT.PUT_LINE('Khong du hang de xuat');
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_dem
    FROM PXuat
    WHERE SoHDX = p_SoHDX;
    IF v_dem > 0 THEN
        UPDATE Xuat
        SET SoLuongX = p_SoLuongX
        WHERE SoHDX = p_SoHDX
        AND MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Da cap nhat phieu xuat');
    ELSE
        INSERT INTO PXuat
        VALUES(p_SoHDX, p_NgayXuat, p_MaNV);
        INSERT INTO Xuat
        VALUES(p_SoHDX, p_MaSP, p_SoLuongX);
        DBMS_OUTPUT.PUT_LINE('Da them phieu xuat');
    END IF;
    COMMIT;
END;
/

-- Phieu 1 cau g

CREATE OR REPLACE PROCEDURE sp_XoaNhanVien(
    p_MaNV VARCHAR2
)
AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem FROM NhanVien WHERE MaNV = p_MaNV;
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Nhan vien khong ton tai');
    ELSE
        DELETE FROM Nhap 
        WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = p_MaNV);
        DELETE FROM Xuat
        WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = p_MaNV);
        DELETE FROM PNhap WHERE MaNV = p_MaNV;
        DELETE FROM PXuat WHERE MaNV = p_MaNV;
        DELETE FROM NhanVien WHERE MaNV = p_MaNV;
        DBMS_OUTPUT.PUT_LINE('Da xoa nhan vien');
        COMMIT;
    END IF;
END;
/

-- Phieu 1 cau h

CREATE OR REPLACE PROCEDURE sp_XoaSanPham(
    p_MaSP VARCHAR2
)
AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = p_MaSP;
    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('San pham khong ton tai');
    ELSE
        DELETE FROM Nhap WHERE MaSP = p_MaSP;
        DELETE FROM Xuat WHERE MaSP = p_MaSP;
        DELETE FROM SanPham WHERE MaSP = p_MaSP;
        DBMS_OUTPUT.PUT_LINE('Da xoa san pham');
        COMMIT;
    END IF;
END;
/

-- Phieu 2 cau a

CREATE OR REPLACE PROCEDURE sp_ThemNhanVien2(
    p_MaNV VARCHAR2,
    p_TenNV VARCHAR2,
    p_GioiTinh VARCHAR2,
    p_DiaChi VARCHAR2,
    p_SoDT VARCHAR2,
    p_Email VARCHAR2,
    p_TenPhong VARCHAR2,
    p_Flag NUMBER,
    p_KQ OUT NUMBER
)
AS
BEGIN
    IF p_GioiTinh <> 'Nam' AND p_GioiTinh <> 'Nu' THEN
        p_KQ := 1;
        RETURN;
    END IF;
    IF p_Flag = 0 THEN
        INSERT INTO NhanVien
        VALUES(p_MaNV,p_TenNV,p_GioiTinh,p_DiaChi,p_SoDT,p_Email,p_TenPhong);
        p_KQ := 0;
    ELSE
        UPDATE NhanVien
        SET TenNV=p_TenNV,
            GioiTinh=p_GioiTinh,
            DiaChi=p_DiaChi,
            SoDT=p_SoDT,
            Email=p_Email,
            TenPhong=p_TenPhong
        WHERE MaNV=p_MaNV;
        p_KQ := 0;
    END IF;
    COMMIT;
END;
/

-- Phieu 2 cau b

CREATE OR REPLACE PROCEDURE sp_ThemMoiSP2(
    p_MaSP VARCHAR2,
    p_TenHang VARCHAR2,
    p_TenSP VARCHAR2,
    p_SoLuong NUMBER,
    p_MauSac VARCHAR2,
    p_GiaBan NUMBER,
    p_DonViTinh VARCHAR2,
    p_MoTa CLOB,
    p_Flag NUMBER,
    p_KQ OUT NUMBER
)
AS
    v_dem NUMBER;
    v_MaHangSX VARCHAR2(10);
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM HangSX
    WHERE TenHang=p_TenHang;
    IF v_dem=0 THEN
        p_KQ := 1;
        RETURN;
    END IF;
    IF p_SoLuong < 0 THEN
        p_KQ := 2;
        RETURN;
    END IF;
    SELECT MaHangSX INTO v_MaHangSX
    FROM HangSX
    WHERE TenHang=p_TenHang;
    IF p_Flag=0 THEN
        INSERT INTO SanPham
        VALUES(p_MaSP,v_MaHangSX,p_TenSP,p_SoLuong,p_MauSac,p_GiaBan,p_DonViTinh,p_MoTa);
    ELSE
        UPDATE SanPham
        SET MaHangSX=v_MaHangSX,
            TenSP=p_TenSP,
            SoLuong=p_SoLuong,
            MauSac=p_MauSac,
            GiaBan=p_GiaBan,
            DonViTinh=p_DonViTinh,
            MoTa=p_MoTa
        WHERE MaSP=p_MaSP;
    END IF;
    p_KQ := 0;
    COMMIT;
END;
/

-- Phieu 2 cau c

CREATE OR REPLACE PROCEDURE sp_XoaNhanVien2(
    p_MaNV VARCHAR2,
    p_KQ OUT NUMBER
)
AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM NhanVien
    WHERE MaNV=p_MaNV;
    IF v_dem=0 THEN
        p_KQ := 1;
        RETURN;
    END IF;
    DELETE FROM Nhap
    WHERE SoHDN IN(SELECT SoHDN FROM PNhap WHERE MaNV=p_MaNV);
    DELETE FROM Xuat
    WHERE SoHDX IN(SELECT SoHDX FROM PXuat WHERE MaNV=p_MaNV);
    DELETE FROM PNhap WHERE MaNV=p_MaNV;
    DELETE FROM PXuat WHERE MaNV=p_MaNV;
    DELETE FROM NhanVien WHERE MaNV=p_MaNV;
    p_KQ := 0;
    COMMIT;
END;
/

-- Phieu 2 cau d

CREATE OR REPLACE PROCEDURE sp_XoaSanPham2(
    p_MaSP VARCHAR2,
    p_KQ OUT NUMBER
)
AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = p_MaSP;
    IF v_dem = 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;
    DELETE FROM Nhap WHERE MaSP = p_MaSP;
    DELETE FROM Xuat WHERE MaSP = p_MaSP;
    DELETE FROM SanPham WHERE MaSP = p_MaSP;
    p_KQ := 0;
    COMMIT;
END;
/

-- Phieu 2 cau e

CREATE OR REPLACE PROCEDURE sp_NhapHangSX2(
    p_MaHangSX VARCHAR2,
    p_TenHang VARCHAR2,
    p_DiaChi VARCHAR2,
    p_SoDT VARCHAR2,
    p_Email VARCHAR2,
    p_KQ OUT NUMBER
)
AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM HangSX
    WHERE TenHang = p_TenHang;
    IF v_dem > 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;
    INSERT INTO HangSX
    VALUES(p_MaHangSX,p_TenHang,p_DiaChi,p_SoDT,p_Email);
    p_KQ := 0;
    COMMIT;
END;
/

-- Phieu 2 cau f

CREATE OR REPLACE PROCEDURE sp_NhapNhap2(
    p_SoHDN VARCHAR2,
    p_MaSP VARCHAR2,
    p_MaNV VARCHAR2,
    p_NgayNhap DATE,
    p_SoLuongN NUMBER,
    p_DonGiaN NUMBER,
    p_KQ OUT NUMBER
)
AS
    v_dem NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = p_MaSP;
    IF v_dem = 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_dem
    FROM NhanVien
    WHERE MaNV = p_MaNV;
    IF v_dem = 0 THEN
        p_KQ := 2;
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_dem
    FROM PNhap
    WHERE SoHDN = p_SoHDN;
    IF v_dem > 0 THEN
        UPDATE Nhap
        SET SoLuongN = p_SoLuongN,
            DonGiaN = p_DonGiaN
        WHERE SoHDN = p_SoHDN AND MaSP = p_MaSP;
    ELSE
        INSERT INTO PNhap
        VALUES(p_SoHDN,p_NgayNhap,p_MaNV);
        INSERT INTO Nhap
        VALUES(p_SoHDN,p_MaSP,p_SoLuongN,p_DonGiaN);
    END IF;
    p_KQ := 0;
    COMMIT;
END;
/

-- Phieu 2 cau g

CREATE OR REPLACE PROCEDURE sp_NhapXuat2(
    p_SoHDX VARCHAR2,
    p_MaSP VARCHAR2,
    p_MaNV VARCHAR2,
    p_NgayXuat DATE,
    p_SoLuongX NUMBER,
    p_KQ OUT NUMBER
)
AS
    v_dem NUMBER;
    v_soluong NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = p_MaSP;
    IF v_dem = 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_dem
    FROM NhanVien
    WHERE MaNV = p_MaNV;
    IF v_dem = 0 THEN
        p_KQ := 2;
        RETURN;
    END IF;
    SELECT SoLuong INTO v_soluong
    FROM SanPham
    WHERE MaSP = p_MaSP;
    IF p_SoLuongX > v_soluong THEN
        p_KQ := 3;
        RETURN;
    END IF;
    SELECT COUNT(*) INTO v_dem
    FROM PXuat
    WHERE SoHDX = p_SoHDX;
    IF v_dem > 0 THEN
        UPDATE Xuat
        SET SoLuongX = p_SoLuongX
        WHERE SoHDX = p_SoHDX AND MaSP = p_MaSP;
    ELSE
        INSERT INTO PXuat
        VALUES(p_SoHDX,p_NgayXuat,p_MaNV);
        INSERT INTO Xuat
        VALUES(p_SoHDX,p_MaSP,p_SoLuongX);
    END IF;
    p_KQ := 0;
    COMMIT;
END;
/