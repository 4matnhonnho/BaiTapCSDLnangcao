CREATE TABLE s_region (
    id NUMBER(7) PRIMARY KEY,
    name VARCHAR2(50) NOT NULL
);

CREATE TABLE s_dept (
    id NUMBER(7) PRIMARY KEY,
    name VARCHAR2(25) NOT NULL,
    region_id NUMBER(7),
    CONSTRAINT s_dept_region_fk FOREIGN KEY (region_id)
    REFERENCES s_region(id)
);

CREATE TABLE s_title (
    title VARCHAR2(50) PRIMARY KEY
);

CREATE TABLE s_emp (
    id NUMBER(7) PRIMARY KEY,
    last_name VARCHAR2(25) NOT NULL,
    first_name VARCHAR2(25),
    userid VARCHAR2(8) UNIQUE,
    start_date DATE,
    comments VARCHAR2(200),
    manager_id NUMBER(7),
    title VARCHAR2(25),
    dept_id NUMBER(7),
    salary NUMBER(11,2),
    commission_pct NUMBER(4,2),
    CONSTRAINT s_emp_dept_fk FOREIGN KEY (dept_id)
    REFERENCES s_dept(id)
);

CREATE TABLE s_customer (
    id NUMBER(7) PRIMARY KEY,
    name VARCHAR2(50),
    phone VARCHAR2(20),
    address VARCHAR2(100),
    city VARCHAR2(50),
    state VARCHAR2(50),
    country VARCHAR2(50),
    zip_code VARCHAR2(10),
    credit_rating VARCHAR2(10),
    sales_rep_id NUMBER(7),
    region_id NUMBER(7),
    comments VARCHAR2(200)
);

CREATE TABLE s_image (
    id NUMBER(7) PRIMARY KEY,
    format VARCHAR2(20),
    use_filename VARCHAR2(10),
    filename VARCHAR2(100),
    image BLOB
);

CREATE TABLE s_longtext (
    id NUMBER(7) PRIMARY KEY,
    use_filename VARCHAR2(10),
    filename VARCHAR2(100),
    text CLOB
);

CREATE TABLE s_product (
    id NUMBER(7) PRIMARY KEY,
    name VARCHAR2(100),
    short_desc VARCHAR2(200),
    longtext_id NUMBER(7),
    image_id NUMBER(7),
    suggested_whlsl_price NUMBER(10,2),
    whlsl_units VARCHAR2(50),
    CONSTRAINT s_product_longtext_fk FOREIGN KEY (longtext_id)
    REFERENCES s_longtext(id),
    CONSTRAINT s_product_image_fk FOREIGN KEY (image_id)
    REFERENCES s_image(id)
);

CREATE TABLE s_ord (
    id NUMBER(7) PRIMARY KEY,
    customer_id NUMBER(7),
    date_ordered DATE,
    date_shipped DATE,
    sales_rep_id NUMBER(7),
    total NUMBER(10,2),
    payment_type VARCHAR2(20),
    order_filled VARCHAR2(10),
    CONSTRAINT s_ord_customer_fk FOREIGN KEY (customer_id)
    REFERENCES s_customer(id)
);

CREATE TABLE s_item (
    ord_id NUMBER(7),
    item_id NUMBER(7),
    product_id NUMBER(7),
    price NUMBER(10,2),
    quantity NUMBER(7),
    quantity_shipped NUMBER(7),
    PRIMARY KEY (ord_id, item_id),
    CONSTRAINT s_item_ord_fk FOREIGN KEY (ord_id)
    REFERENCES s_ord(id),
    CONSTRAINT s_item_product_fk FOREIGN KEY (product_id)
    REFERENCES s_product(id)
);

CREATE TABLE s_warehouse (
    id NUMBER(7) PRIMARY KEY,
    region_id NUMBER(7),
    address VARCHAR2(100),
    city VARCHAR2(50),
    state VARCHAR2(50),
    country VARCHAR2(50),
    zip_code VARCHAR2(10),
    phone VARCHAR2(20),
    manager_id NUMBER(7),
    CONSTRAINT s_warehouse_region_fk FOREIGN KEY (region_id)
    REFERENCES s_region(id)
);

CREATE TABLE s_inventory (
    product_id NUMBER(7),
    warehouse_id NUMBER(7),
    amount_in_stock NUMBER(7),
    reorder_point NUMBER(7),
    max_in_stock NUMBER(7),
    out_of_stock_explanation VARCHAR2(200),
    restock_date DATE,
    PRIMARY KEY (product_id, warehouse_id),
    CONSTRAINT s_inventory_product_fk FOREIGN KEY (product_id)
    REFERENCES s_product(id),
    CONSTRAINT s_inventory_warehouse_fk FOREIGN KEY (warehouse_id)
    REFERENCES s_warehouse(id)
);

@BaiTH_Buoi1.sql;

Show user;

SELECT table_name FROM user_tables;

INSERT INTO s_customer VALUES (101, 'Nguyen Van An', '0901234567', '12 Nguyen Trai', 'HCM', 'VN', 'Vietnam', '700000', 'A', 201, 1, NULL);
INSERT INTO s_customer VALUES (102, 'Tran Thi Banh', '0902345678', '34 Le Loi', 'HCM', 'VN', 'Vietnam', '700000', 'B', 202, 2, NULL);
INSERT INTO s_customer VALUES (103, 'Le Van Cung', '0903456789', '56 Hai Ba Trung', 'HCM', 'VN', 'Vietnam', '700000', 'A', 203, 3, NULL);
INSERT INTO s_customer VALUES (104, 'Pham Thi Danh', '0904567890', '78 Vo Van Tan', 'HCM', 'VN', 'Vietnam', '700000', 'C', 204, 1, NULL);
INSERT INTO s_customer VALUES (105, 'Hoang Van Em', '0905678901', '90 Dien Bien Phu', 'HCM', 'VN', 'Vietnam', '700000', 'B', 205, 2, NULL);
INSERT INTO s_customer VALUES (106, 'Nguyen Thi Hoa', '0906789012', '11 Pasteur', 'HCM', 'VN', 'Vietnam', '700000', 'A', 206, 3, NULL);
INSERT INTO s_customer VALUES (107, 'Tran Van Good', '0907890123', '22 Nam Ky Khoi Nghia', 'HCM', 'VN', 'Vietnam', '700000', 'B', 207, 1, NULL);
INSERT INTO s_customer VALUES (108, 'Le Thi Hong', '0908901234', '33 Ly Tu Trong', 'HCM', 'VN', 'Vietnam', '700000', 'C', 208, 2, NULL);
INSERT INTO s_customer VALUES (109, 'Pham Van Iot', '0909012345', '44 Nguyen Hue', 'HCM', 'VN', 'Vietnam', '700000', 'A', 209, 3, NULL);
INSERT INTO s_customer VALUES (110, 'Hoang Thi Khanh', '0910123456', '55 Dong Khoi', 'HCM', 'VN', 'Vietnam', '700000', 'B', 210, 1, NULL);
INSERT INTO s_customer VALUES (111, 'Nguyen Van Luong', '0911234567', '66 Cach Mang Thang 8', 'HCM', 'VN', 'Vietnam', '700000', 'A', 211, 2, NULL);
INSERT INTO s_customer VALUES (112, 'Tran Thi Mot', '0912345678', '77 Truong Dinh', 'HCM', 'VN', 'Vietnam', '700000', 'C', 212, 3, NULL);
INSERT INTO s_customer VALUES (113, 'Le Van Nhan', '0913456789', '88 Nguyen Thi Minh Khai', 'HCM', 'VN', 'Vietnam', '700000', 'B', 213, 1, NULL);
INSERT INTO s_customer VALUES (114, 'Pham Thi Oanh', '0914567890', '99 Ton Duc Thang', 'HCM', 'VN', 'Vietnam', '700000', 'A', 214, 2, NULL);
INSERT INTO s_customer VALUES (115, 'Hoang Van Phu', '0915678901', '101 Ho Tung Mau', 'HCM', 'VN', 'Vietnam', '700000', 'B', 215, 3, NULL);
INSERT INTO s_customer VALUES (116, 'Nguyen Thi Quyen', '0916789012', '202 Pham Ngu Lao', 'HCM', 'VN', 'Vietnam', '700000', 'C', 216, 1, NULL);
INSERT INTO s_customer VALUES (117, 'Tran Van Ra', '0917890123', '303 Nguyen Cong Tru', 'HCM', 'VN', 'Vietnam', '700000', 'A', 217, 2, NULL);
INSERT INTO s_customer VALUES (118, 'Le Thi Sau', '0918901234', '404 Bui Vien', 'HCM', 'VN', 'Vietnam', '700000', 'B', 218, 3, NULL);
INSERT INTO s_customer VALUES (119, 'Pham Van Toi', '0919012345', '505 Phan Xich Long', 'HCM', 'VN', 'Vietnam', '700000', 'C', 219, 1, NULL);
INSERT INTO s_customer VALUES (120, 'Hoang Thi Ung', '0920123456', '606 Nguyen Oanh', 'HCM', 'VN', 'Vietnam', '700000', 'A', 220, 2, NULL);
COMMIT;

-- B�i 2 c�u 1

SELECT name AS "Ten khach hang",
       id AS "Ma khach hang"
FROM s_customer
ORDER BY id DESC;

-- B�i 2 c�u 2
INSERT INTO s_region VALUES (1, 'Region 1');
INSERT INTO s_region VALUES (2, 'Region 2');
INSERT INTO s_region VALUES (3, 'Region 3');

INSERT INTO s_dept (id, name, region_id) VALUES (10, 'Sales', 1);
INSERT INTO s_dept (id, name, region_id) VALUES (20, 'HR', 1);
INSERT INTO s_dept (id, name, region_id) VALUES (30, 'IT', 2);
INSERT INTO s_dept (id, name, region_id) VALUES (40, 'Finance', 2);
INSERT INTO s_dept (id, name, region_id) VALUES (50, 'Marketing', 3);

INSERT INTO s_emp VALUES (201, 'Nguyen', 'An', 'AN01', DATE '1990-05-14', NULL, NULL, 'Manager', 10, 2000, NULL);
INSERT INTO s_emp VALUES (202, 'Tran', 'Binh', 'BINH02', DATE '1991-03-20',  NULL, 201, 'Staff', 10, 1500, NULL);
INSERT INTO s_emp VALUES (203, 'Le', 'Cuong', 'CUONG03', DATE '1992-07-11', NULL, 201, 'Staff', 20, 1300, NULL);
INSERT INTO s_emp VALUES (204, 'Pham', 'Dung', 'DUNG04', DATE '1990-11-05', NULL, 201, 'Staff', 20, 1400, NULL);
INSERT INTO s_emp VALUES (205, 'Hoang', 'Em', 'EM05', DATE '1993-01-15', NULL, 201, 'Staff', 30, 1200, NULL);
INSERT INTO s_emp VALUES (206, 'Nguyen', 'Giang', 'GIANG06', DATE '1991-06-22', NULL, 201, 'Staff', 30, 1600, NULL);
INSERT INTO s_emp VALUES (207, 'Tran', 'Hieu', 'HIEU07', DATE '1990-09-09', NULL, 201, 'Staff', 40, 1700, NULL);
INSERT INTO s_emp VALUES (208, 'Le', 'Khanh', 'KHANH08', DATE '1992-02-02', NULL, 201, 'Staff', 40, 1100, NULL);
INSERT INTO s_emp VALUES (209, 'Pham', 'Long', 'LONG09', DATE '1991-12-12', NULL, 201, 'Staff', 50, 1800, NULL);
INSERT INTO s_emp VALUES (210, 'Hoang', 'Minh', 'MINH10', DATE '1990-08-18', NULL, 201, 'Staff', 50, 1900, NULL);
INSERT INTO s_emp VALUES (211, 'Nguyen', 'Nam', 'NAM11', DATE '1993-04-25', NULL, 202, 'Staff', 10, 1000, NULL);
INSERT INTO s_emp VALUES (212, 'Tran', 'Oanh', 'OANH12', DATE '1991-07-30', NULL, 202, 'Staff', 20, 1550, NULL);
INSERT INTO s_emp VALUES (213, 'Le', 'Phuc', 'PHUC13', DATE '1992-09-14', NULL, 203, 'Staff', 30, 1450, NULL);
INSERT INTO s_emp VALUES (214, 'Pham', 'Quang', 'QUANG14', DATE '1990-03-03', NULL, 203, 'Staff', 40, 1350, NULL);
INSERT INTO s_emp VALUES (215, 'Hoang', 'Son', 'SON15', DATE '1991-10-10', NULL, 204, 'Staff', 50, 1250, NULL);
INSERT INTO s_emp VALUES (216, 'Nguyen', 'Trang', 'TRANG16', DATE '1992-06-06', NULL, 204, 'Staff', 10, 1650, NULL);
INSERT INTO s_emp VALUES (217, 'Tran', 'Uyen', 'UYEN17', DATE '1993-08-08', NULL, 205, 'Staff', 20, 1750, NULL);
INSERT INTO s_emp VALUES (218, 'Le', 'Vinh', 'VINH18', DATE '1990-01-01', NULL, 205, 'Staff', 30, 1850, NULL);
INSERT INTO s_emp VALUES (219, 'Pham', 'Xuan', 'XUAN19', DATE '1991-05-05', NULL, 206, 'Staff', 40, 1950, NULL);
INSERT INTO s_emp VALUES (220, 'Hoang', 'Yen', 'YEN20', DATE '1992-11-11', NULL, 206, 'Staff', 50, 2000, NULL);
COMMIT;

SELECT first_name || ' ' || last_name AS "Nhan Vien",
       dept_id
FROM s_emp
WHERE dept_id IN (10, 50)
ORDER BY first_name;

--- C�u 3

SELECT last_name, first_name
FROM s_emp
WHERE first_name LIKE '%S%'
   OR last_name LIKE '%S%';
   
--- C�u 4 

SELECT userid, start_date
FROM s_emp
WHERE start_date BETWEEN TO_DATE('14/05/1990','DD/MM/YYYY') AND TO_DATE('26/05/1991','DD/MM/YYYY');

-- c�u 5

SELECT last_name, salary
FROM s_emp
WHERE salary BETWEEN 1000 AND 2000;

-- c�u 6

INSERT INTO s_dept (id, name, region_id) VALUES (31, 'Dept31', 1);
INSERT INTO s_dept (id, name, region_id) VALUES (42, 'Dept42', 2);

INSERT INTO s_emp VALUES (221, 'Nguyen', 'A31', 'A31_1', DATE '1991-01-01', NULL, 201, 'Staff', 31, 1500, NULL);
INSERT INTO s_emp VALUES (222, 'Tran', 'B31', 'B31_2', DATE '1992-02-02', NULL, 201, 'Staff', 31, 1600, NULL);
INSERT INTO s_emp VALUES (223, 'Le', 'A42', 'A42_1', DATE '1991-03-03', NULL, 202, 'Staff', 42, 1700, NULL);
INSERT INTO s_emp VALUES (224, 'Pham', 'B42', 'B42_2', DATE '1992-04-04', NULL, 202, 'Staff', 42, 1800, NULL);
COMMIT;

SELECT last_name || ' ' || first_name AS "Employee Name",
       salary AS "Monthly Salary"
FROM s_emp
WHERE dept_id IN (31, 42, 50)
  AND salary > 1350;
  
-- c�u 7

SELECT last_name, start_date
FROM s_emp
WHERE TO_CHAR(start_date, 'YYYY') = '1991';

-- c�u 8

SELECT last_name, first_name
FROM s_emp
WHERE id NOT IN (
    SELECT DISTINCT manager_id
    FROM s_emp
    WHERE manager_id IS NOT NULL
);

-- c�u 9

INSERT INTO s_longtext VALUES (1, 'Y', 'desc1.txt', 'Detailed description 1');
INSERT INTO s_longtext VALUES (2, 'Y', 'desc2.txt', 'Detailed description 2');
INSERT INTO s_longtext VALUES (3, 'Y', 'desc3.txt', 'Detailed description 3');
INSERT INTO s_longtext VALUES (4, 'Y', 'desc4.txt', 'Detailed description 4');
INSERT INTO s_longtext VALUES (5, 'Y', 'desc5.txt', 'Detailed description 5');

INSERT INTO s_image VALUES (1, 'jpg', 'Y', 'img1.jpg', NULL);
INSERT INTO s_image VALUES (2, 'jpg', 'Y', 'img2.jpg', NULL);
INSERT INTO s_image VALUES (3, 'jpg', 'Y', 'img3.jpg', NULL);
INSERT INTO s_image VALUES (4, 'jpg', 'Y', 'img4.jpg', NULL);
INSERT INTO s_image VALUES (5, 'jpg', 'Y', 'img5.jpg', NULL);

INSERT INTO s_product VALUES (1, 'Product A', 'Mountain bicycle', 1, 1, 1200, 'unit');
INSERT INTO s_product VALUES (2, 'Product B', 'Road bicycle', 2, 2, 1500, 'unit');
INSERT INTO s_product VALUES (3, 'Product C', 'Electric bicycle', 3, 3, 2000, 'unit');
INSERT INTO s_product VALUES (4, 'Product D', 'Helmet', 1, 1, 100, 'unit');
INSERT INTO s_product VALUES (5, 'Product E', 'Bike gloves', 2, 2, 50, 'unit');

INSERT INTO s_product VALUES (6, 'San Pham F', 'Bike light', 3, 3, 80, 'unit');
INSERT INTO s_product VALUES (7, 'San Pham G', 'Bike lock', 4, 4, 60, 'unit');
INSERT INTO s_product VALUES (8, 'San Pham H', 'Water bottle', 5, 5, 20, 'unit');
INSERT INTO s_product VALUES (9, 'San Pham I', 'Bike pump', 1, 1, 70, 'unit');
INSERT INTO s_product VALUES (10, 'San Pham J', 'Repair kit', 2, 2, 40, 'unit');

INSERT INTO s_product VALUES (11, 'San PhamK', 'Mini bicycle', 3, 3, 900, 'unit');
INSERT INTO s_product VALUES (12, 'San Pham L', 'Kids bicycle', 4, 4, 800, 'unit');
INSERT INTO s_product VALUES (13, 'San Pham M', 'Pro bicycle X', 5, 5, 2500, 'unit');
INSERT INTO s_product VALUES (14, 'San Pham N', 'Pro bicycle Y', 1, 1, 2700, 'unit');
INSERT INTO s_product VALUES (15, 'San Pham O', 'Cycling shoes', 2, 2, 300, 'unit');

INSERT INTO s_product VALUES (16, 'Product P', 'Cycling jersey', 3, 3, 120, 'unit');
INSERT INTO s_product VALUES (17, 'Product Q', 'Bike seat', 4, 4, 90, 'unit');
INSERT INTO s_product VALUES (18, 'Product R', 'Bike tire', 5, 5, 110, 'unit');
INSERT INTO s_product VALUES (19, 'Product S', 'Bike chain', 1, 1, 45, 'unit');
INSERT INTO s_product VALUES (20, 'Product T', 'Bike mirror', 2, 2, 35, 'unit');
COMMIT;

SELECT name
FROM s_product
WHERE name LIKE 'Pro%'
ORDER BY name ASC;

-- cau 10

SELECT name, short_desc
FROM s_product
WHERE LOWER(short_desc) LIKE '%bicycle%';

-- c�u 11

SELECT short_desc
FROM s_product;

-- c�u 12

SELECT last_name || ' ' || first_name || ' (' || title || ')' AS "Nhan vien"
FROM s_emp;

-- B�i 3 
UPDATE s_product
SET name = 'Ski bike'
WHERE id = 1;

INSERT INTO s_ord VALUES (101, 101, TO_DATE('01/01/2020','DD/MM/YYYY'), TO_DATE('05/01/2020','DD/MM/YYYY'), NULL, 120000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (102, 102, TO_DATE('02/01/2020','DD/MM/YYYY'), TO_DATE('06/01/2020','DD/MM/YYYY'), NULL, 80000, 'CARD', 'Y');
INSERT INTO s_ord VALUES (103, 103, TO_DATE('03/01/2020','DD/MM/YYYY'), TO_DATE('07/01/2020','DD/MM/YYYY'), NULL, 150000, 'CASH', 'N');
INSERT INTO s_ord VALUES (104, 104, TO_DATE('04/01/2020','DD/MM/YYYY'), TO_DATE('08/01/2020','DD/MM/YYYY'), NULL, 200000, 'CARD', 'Y');
INSERT INTO s_ord VALUES (105, 105, TO_DATE('05/01/2020','DD/MM/YYYY'), TO_DATE('09/01/2020','DD/MM/YYYY'), NULL, 50000, 'CASH', 'N');

INSERT INTO s_ord VALUES (106, 106, TO_DATE('06/01/2020','DD/MM/YYYY'), TO_DATE('10/01/2020','DD/MM/YYYY'), NULL, 300000, 'CARD', 'Y');
INSERT INTO s_ord VALUES (107, 107, TO_DATE('07/01/2020','DD/MM/YYYY'), TO_DATE('11/01/2020','DD/MM/YYYY'), NULL, 110000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (108, 108, TO_DATE('08/01/2020','DD/MM/YYYY'), TO_DATE('12/01/2020','DD/MM/YYYY'), NULL, 90000, 'CARD', 'N');
INSERT INTO s_ord VALUES (109, 109, TO_DATE('09/01/2020','DD/MM/YYYY'), TO_DATE('13/01/2020','DD/MM/YYYY'), NULL, 250000, 'CASH', 'Y');
INSERT INTO s_ord VALUES (110, 110, TO_DATE('10/01/2020','DD/MM/YYYY'), TO_DATE('14/01/2020','DD/MM/YYYY'), NULL, 70000, 'CARD', 'N');

COMMIT;

-- c�u 1

SELECT id,
       last_name,
       ROUND(salary * 1.15, 2) AS "Luong moi"
FROM s_emp;

-- cau 2

SELECT last_name,
       start_date,
       TO_CHAR(
           NEXT_DAY(ADD_MONTHS(start_date, 6), 'MONDAY'),
           'Ddspth "of" Month YYYY'
       ) AS "Ngay xet tang luong"
FROM s_emp;

-- cau 3

SELECT name
FROM s_product
WHERE LOWER(name) LIKE '%ski%';

-- c�u 4

SELECT last_name,
       ROUND(MONTHS_BETWEEN(SYSDATE, start_date)) AS "So thang tham nien"
FROM s_emp
ORDER BY MONTHS_BETWEEN(SYSDATE, start_date) ASC;

-- c�u 5

SELECT COUNT(DISTINCT manager_id) AS "So nguoi quan ly"
FROM s_emp
WHERE manager_id IS NOT NULL;

-- c�u 6

SELECT MAX(total) AS "Highest",
       MIN(total) AS "Lowest"
FROM s_ord;

-- Bai 4

INSERT INTO s_item VALUES (101, 1, 1, 1200, 2, 2);
INSERT INTO s_item VALUES (101, 2, 2, 1500, 1, 1);
INSERT INTO s_item VALUES (102, 1, 3, 2000, 1, 1);
INSERT INTO s_item VALUES (103, 1, 4, 100, 5, 5);
INSERT INTO s_item VALUES (104, 1, 5, 50, 10, 10);

INSERT INTO s_item VALUES (105, 1, 6, 80, 3, 3);
INSERT INTO s_item VALUES (106, 1, 7, 60, 4, 4);
INSERT INTO s_item VALUES (107, 1, 8, 20, 6, 6);
INSERT INTO s_item VALUES (108, 1, 9, 70, 2, 2);
INSERT INTO s_item VALUES (109, 1, 10, 40, 3, 3);

COMMIT;

-- c�u 1

SELECT p.name,
       p.id,
       i.quantity AS "ORDERED"
FROM s_product p, s_item i
WHERE p.id = i.product_id
  AND i.ord_id = 101;
  
-- c�u 2

SELECT c.id AS "Ma khach hang",
       o.id AS "Ma don hang"
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id(+)
ORDER BY c.id;

-- c�u 3

SELECT o.customer_id,
       i.product_id,
       i.quantity
FROM s_ord o, s_item i
WHERE o.id = i.ord_id
  AND o.total > 100000;
  
-- B�i 5

-- cau 1

SELECT manager_id AS "Ma quan ly",
       COUNT(id) AS "So nhan vien"
FROM s_emp
WHERE manager_id IS NOT NULL
GROUP BY manager_id
ORDER BY manager_id;

-- cau 2
INSERT INTO s_emp VALUES (301, 'Nguyen', 'A', 'user301', TO_DATE('01/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 10, 1200, NULL);
INSERT INTO s_emp VALUES (302, 'Tran', 'B', 'user302', TO_DATE('02/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 10, 1300, NULL);
INSERT INTO s_emp VALUES (303, 'Le', 'C', 'user303', TO_DATE('03/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 20, 1400, NULL);
INSERT INTO s_emp VALUES (304, 'Pham', 'D', 'user304', TO_DATE('04/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 20, 1500, NULL);
INSERT INTO s_emp VALUES (305, 'Hoang', 'E', 'user305', TO_DATE('05/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 30, 1600, NULL);
INSERT INTO s_emp VALUES (306, 'Vu', 'F', 'user306', TO_DATE('06/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 30, 1700, NULL);
INSERT INTO s_emp VALUES (307, 'Dang', 'G', 'user307', TO_DATE('07/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 40, 1800, NULL);
INSERT INTO s_emp VALUES (308, 'Bui', 'H', 'user308', TO_DATE('08/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 40, 1900, NULL);
INSERT INTO s_emp VALUES (309, 'Do', 'I', 'user309', TO_DATE('09/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 50, 2000, NULL);
INSERT INTO s_emp VALUES (310, 'Ngo', 'K', 'user310', TO_DATE('10/01/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 50, 2100, NULL);
COMMIT;

SELECT manager_id AS "Ma quan ly",
       COUNT(id) AS "So nhan vien"
FROM s_emp
WHERE manager_id IS NOT NULL
GROUP BY manager_id
HAVING COUNT(id) >= 20;

-- cau 3

SELECT r.id AS "Ma vung",
       r.name AS "Ten vung",
       COUNT(d.id) AS "So phong ban"
FROM s_region r, s_dept d
WHERE r.id = d.region_id
GROUP BY r.id, r.name
ORDER BY r.id;

-- cau 4

SELECT c.name AS "Ten khach hang",
       COUNT(o.id) AS "So don dat hang"
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name
ORDER BY c.name;

-- c�u 5
INSERT INTO s_ord VALUES (111, 101, TO_DATE('15/01/2020','DD/MM/YYYY'), TO_DATE('20/01/2020','DD/MM/YYYY'), NULL, 180000, 'CASH', 'Y');
COMMIT;

SELECT c.name,
       COUNT(o.id) AS "So don hang"
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name
HAVING COUNT(o.id) = (
    SELECT MAX(COUNT(id))
    FROM s_ord
    GROUP BY customer_id
);

-- cau 6

SELECT c.name,
       SUM(o.total) AS "Tong tien"
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name
HAVING SUM(o.total) = (
    SELECT MAX(SUM(total))
    FROM s_ord
    GROUP BY customer_id
);

-- B�i 6 
INSERT INTO s_emp VALUES (400, 'Nguyen', 'Lan', 'lan400', TO_DATE('01/03/2020','DD/MM/YYYY'), NULL, 201, 'Staff', 10, 1500, NULL);
COMMIT;
-- C�u 1

SELECT last_name, first_name, start_date
FROM s_emp
WHERE dept_id = (
    SELECT dept_id
    FROM s_emp
    WHERE first_name = 'Lan'
)
AND first_name != 'Lan';

-- C�u 2
SELECT id, last_name, first_name, userid
FROM s_emp
WHERE salary > (
    SELECT AVG(salary)
    FROM s_emp
);

-- C�u 3
SELECT id, last_name, first_name
FROM s_emp
WHERE salary > (
    SELECT AVG(salary)
    FROM s_emp
)
AND (UPPER(first_name) LIKE '%L%' OR UPPER(last_name) LIKE '%L%');

-- C�u 4
SELECT name
FROM s_customer
WHERE id NOT IN (
    SELECT customer_id
    FROM s_ord
    WHERE customer_id IS NOT NULL
);