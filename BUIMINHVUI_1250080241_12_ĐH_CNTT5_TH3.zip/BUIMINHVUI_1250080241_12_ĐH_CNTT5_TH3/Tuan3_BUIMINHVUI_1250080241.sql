CREATE TABLE COURSE (
    CourseNo NUMBER(8,0) PRIMARY KEY,
    Description VARCHAR2(50),
    Cost NUMBER(9,2),
    Prerequisite NUMBER(8,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,
    CONSTRAINT fk_course_prereq  FOREIGN KEY (Prerequisite) REFERENCES COURSE(CourseNo)
);
CREATE TABLE INSTRUCTOR (
    InstructorID NUMBER(8,0) PRIMARY KEY,
    Salutation VARCHAR2(5),
    FirstName VARCHAR2(25),
    LastName VARCHAR2(25),
    Address VARCHAR2(50),
    Phone VARCHAR2(15),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);
CREATE TABLE STUDENT (
    StudentID NUMBER(8,0) PRIMARY KEY,
    Salutation VARCHAR2(5),
    FirstName VARCHAR2(25),
    LastName VARCHAR2(25) NOT NULL,
    Address VARCHAR2(50),
    Phone VARCHAR2(15),
    Employer VARCHAR2(50),
    RegistrationDate DATE NOT NULL,
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);
CREATE TABLE CLASS (
    ClassID NUMBER(8,0) PRIMARY KEY,
    CourseNo NUMBER(8,0) NOT NULL,
    ClassNo NUMBER(3),
    StartDateTime DATE,
    Location VARCHAR2(50),
    InstructorID NUMBER(8,0) NOT NULL,
    Capacity NUMBER(3,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,
    CONSTRAINT fk_class_course FOREIGN KEY (CourseNo) REFERENCES COURSE(CourseNo),
    CONSTRAINT fk_class_instructor FOREIGN KEY (InstructorID) REFERENCES INSTRUCTOR(InstructorID)
);
CREATE TABLE ENROLLMENT (
    StudentID NUMBER(8,0),
    ClassID NUMBER(8,0),
    EnrollDate DATE NOT NULL,
    FinalGrade NUMBER(3,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,
    CONSTRAINT pk_enrollment PRIMARY KEY (StudentID, ClassID),
    CONSTRAINT fk_enrollment_student FOREIGN KEY (StudentID) REFERENCES STUDENT(StudentID),
    CONSTRAINT fk_enrollment_class FOREIGN KEY (ClassID) REFERENCES CLASS(ClassID)
);
CREATE TABLE GRADE (
    StudentID NUMBER(8,0),
    ClassID NUMBER(8,0),
    Grade NUMBER(3,0) NOT NULL,
    Comments VARCHAR2(2000),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,
    CONSTRAINT pk_grade PRIMARY KEY (StudentID, ClassID),
    CONSTRAINT fk_grade_enrollment FOREIGN KEY (StudentID, ClassID)  REFERENCES ENROLLMENT(StudentID, ClassID)
);

INSERT INTO COURSE VALUES (1,'C? s? d? li?u',100,NULL,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (2,'SQL n�ng cao',150,1,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (3,'L?p tr�nh PL/SQL',200,2,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (4,'L?p tr�nh Java c? b?n',180,NULL,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (5,'Spring Boot',250,4,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (6,'Python c? b?n',120,NULL,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (7,'Khoa h?c d? li?u',300,6,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (8,'H?c m�y',350,7,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (9,'HTML c? b?n',80,NULL,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (10,'CSS c? b?n',90,9,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (11,'JavaScript',120,9,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (12,'ReactJS',200,11,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (13,'NodeJS',200,11,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (14,'C? s? d? li?u MongoDB',150,NULL,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (15,'DevOps',300,NULL,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (16,'Docker',180,15,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (17,'Kubernetes',320,16,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (18,'Tr� tu? nh�n t?o',400,NULL,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (19,'H?c s�u',450,18,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO COURSE VALUES (20,'?i?n to�n ?�m m�y AWS',350,NULL,'quantri',SYSDATE,'quantri',SYSDATE);

INSERT INTO INSTRUCTOR VALUES (1,'�ng','An','Nguy?n','TP.HCM','0901','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (2,'B�','B�nh','Tr?n','TP.HCM','0902','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (3,'�ng','C??ng','L�','TP.HCM','0903','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (4,'B�','Dung','Ph?m','TP.HCM','0904','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (5,'�ng','H�ng','V�','TP.HCM','0905','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (6,'B�','Lan','Nguy?n','TP.HCM','0906','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (7,'�ng','Minh','Tr?n','TP.HCM','0907','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (8,'B�','Nga','L�','TP.HCM','0908','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (9,'�ng','Phong','Ph?m','TP.HCM','0909','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (10,'B�','Qu?nh','V�','TP.HCM','0910','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (11,'�ng','S?n','Nguy?n','TP.HCM','0911','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (12,'B�','Trang','Tr?n','TP.HCM','0912','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (13,'�ng','Tu?n','L�','TP.HCM','0913','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (14,'B�','Vy','Ph?m','TP.HCM','0914','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (15,'�ng','Khoa','V�','TP.HCM','0915','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (16,'B�','Linh','Nguy?n','TP.HCM','0916','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (17,'�ng','Nam','Tr?n','TP.HCM','0917','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (18,'B�','Oanh','L�','TP.HCM','0918','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (19,'�ng','Ph�c','Ph?m','TP.HCM','0919','quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO INSTRUCTOR VALUES (20,'B�','Y?n','V�','TP.HCM','0920','quantri',SYSDATE,'quantri',SYSDATE);

INSERT INTO STUDENT VALUES (1,'�ng','Nam','Nguy?n','TP.HCM','0801','FPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (2,'B�','B�nh','Tr?n','TP.HCM','0802','VNG',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (3,'�ng','C??ng','L�','TP.HCM','0803','Shopee',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (4,'B�','D??ng','Ph?m','TP.HCM','0804','VNPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (5,'�ng','Em','V�','TP.HCM','0805','FPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (6,'B�','Ph�t','Nguy?n','TP.HCM','0806','VNG',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (7,'�ng','Giao','Tr?n','TP.HCM','0807','Shopee',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (8,'B�','Hoa','L�','TP.HCM','0808','VNPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (9,'�ng','Y?n','Ph?m','TP.HCM','0809','FPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (10,'B�','V?n','V�','TP.HCM','0810','VNG',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (11,'�ng','Kh?i','Nguy?n','TP.HCM','0811','Shopee',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (12,'B�','L�m','Tr?n','TP.HCM','0812','VNPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (13,'�ng','M?nh','L�','TP.HCM','0813','FPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (14,'B�','Ninh','Ph?m','TP.HCM','0814','VNG',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (15,'�ng','Oanh','V�','TP.HCM','0815','Shopee',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (16,'B�','Ph�ng','Nguy?n','TP.HCM','0816','VNPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (17,'�ng','Quang','Tr?n','TP.HCM','0817','FPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (18,'B�','Li�m','L�','TP.HCM','0818','VNG',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (19,'�ng','S�u','Ph?m','TP.HCM','0819','Shopee',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);
INSERT INTO STUDENT VALUES (20,'B�','Tr�','V�','TP.HCM','0820','VNPT',SYSDATE,'quantri',SYSDATE,'quantri',SYSDATE);

INSERT INTO CLASS VALUES (1,1,1,SYSDATE,'A1',1,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (2,2,1,SYSDATE,'A2',2,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (3,3,1,SYSDATE,'A3',3,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (4,4,1,SYSDATE,'A4',4,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (5,5,1,SYSDATE,'A5',5,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (6,6,1,SYSDATE,'A6',6,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (7,7,1,SYSDATE,'A7',7,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (8,8,1,SYSDATE,'A8',8,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (9,9,1,SYSDATE,'A9',9,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (10,10,1,SYSDATE,'A10',10,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (11,11,1,SYSDATE,'A11',11,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (12,12,1,SYSDATE,'A12',12,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (13,13,1,SYSDATE,'A13',13,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (14,14,1,SYSDATE,'A14',14,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (15,15,1,SYSDATE,'A15',15,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (16,16,1,SYSDATE,'A16',16,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (17,17,1,SYSDATE,'A17',17,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (18,18,1,SYSDATE,'A18',18,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (19,19,1,SYSDATE,'A19',19,30,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO CLASS VALUES (20,20,1,SYSDATE,'A20',20,30,'admin',SYSDATE,'admin',SYSDATE);

INSERT INTO ENROLLMENT VALUES (1,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (2,2,SYSDATE,85,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (3,3,SYSDATE,75,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (4,4,SYSDATE,90,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (5,5,SYSDATE,70,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (6,6,SYSDATE,88,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (7,7,SYSDATE,92,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (8,8,SYSDATE,60,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (9,9,SYSDATE,77,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (10,10,SYSDATE,83,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (11,11,SYSDATE,89,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (12,12,SYSDATE,91,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (13,13,SYSDATE,68,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (14,14,SYSDATE,74,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (15,15,SYSDATE,86,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (16,16,SYSDATE,79,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (17,17,SYSDATE,95,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (18,18,SYSDATE,82,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (19,19,SYSDATE,73,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (20,20,SYSDATE,87,'admin',SYSDATE,'admin',SYSDATE);

INSERT INTO GRADE VALUES (1,1,80,'Good','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (2,2,85,'Good','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (3,3,75,'Average','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (4,4,90,'Excellent','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (5,5,70,'Average','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (6,6,88,'Good','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (7,7,92,'Excellent','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (8,8,60,'Weak','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (9,9,77,'Average','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (10,10,83,'Good','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (11,11,89,'Good','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (12,12,91,'Excellent','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (13,13,68,'Average','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (14,14,74,'Average','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (15,15,86,'Good','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (16,16,79,'Average','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (17,17,95,'Excellent','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (18,18,82,'Good','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (19,19,73,'Average','admin',SYSDATE,'admin',SYSDATE);
INSERT INTO GRADE VALUES (20,20,87,'Good','admin',SYSDATE,'admin',SYSDATE);
COMMIT;

SET SERVEROUTPUT ON;

-- cau 1a
CREATE TABLE Cau1 ( 
ID NUMBER, 
NAME VARCHAR2(20) 
);
-- cau 1b
CREATE SEQUENCE Cau1Seq 
START WITH 5 
INCREMENT BY 5;
-- cau 1c
SET SERVEROUTPUT ON;

DECLARE 
    v_name VARCHAR2(50); 
    v_id NUMBER; 
BEGIN 
-- [d] Sinh vien dang ki nhieu nhat
SELECT firstname || ' ' || lastname 
INTO v_name 
FROM student 
WHERE studentid = ( 
    SELECT studentid FROM enrollment 
    GROUP BY studentid 
    HAVING COUNT(*) = (
        SELECT MAX(COUNT(*)) FROM enrollment GROUP BY studentid
    ) 
    FETCH FIRST 1 ROWS ONLY 
); 
INSERT INTO Cau1 (ID, NAME) 
VALUES (Cau1Seq.NEXTVAL, v_name); 
SAVEPOINT sp_a; 
-- [e] Sinh vien dang ki it nhat
SELECT firstname || ' ' || lastname 
INTO v_name 
FROM student 
WHERE studentid = ( 
    SELECT studentid FROM enrollment 
    GROUP BY studentid 
    HAVING COUNT(*) = (
        SELECT MIN(COUNT(*)) FROM enrollment GROUP BY studentid
    ) 
    FETCH FIRST 1 ROWS ONLY 
); 
INSERT INTO Cau1 (ID, NAME) 
VALUES (Cau1Seq.NEXTVAL, v_name); 
SAVEPOINT sp_b; 
-- [f] Giao vien day nhieu lop nhat
SELECT i.firstname || ' ' || i.lastname 
INTO v_name 
FROM instructor i 
WHERE i.instructorid = ( 
    SELECT instructorid FROM class 
    GROUP BY instructorid 
    HAVING COUNT(*) = (
        SELECT MAX(COUNT(*)) FROM class GROUP BY instructorid
    ) 
    FETCH FIRST 1 ROWS ONLY 
); 
INSERT INTO Cau1 (ID, NAME) 
VALUES (Cau1Seq.NEXTVAL, v_name); 
SAVEPOINT sp_c; 
-- [g] Lay ID vua insert
SELECT ID INTO v_id
FROM Cau1
WHERE NAME = v_name;
DBMS_OUTPUT.PUT_LINE('ID giao vien nhieu lop: ' || v_id); 
-- [h] rollback
ROLLBACK TO sp_b; 
-- [i] Giao vien it lop nhat (dung v_id)
SELECT i.firstname || ' ' || i.lastname 
INTO v_name 
FROM instructor i 
WHERE i.instructorid = ( 
    SELECT instructorid FROM class 
    GROUP BY instructorid 
    HAVING COUNT(*) = (
        SELECT MIN(COUNT(*)) FROM class GROUP BY instructorid
    ) 
    FETCH FIRST 1 ROWS ONLY 
); 
INSERT INTO Cau1 (ID, NAME) 
VALUES (v_id, v_name); 
-- [j] Them lai giao vien nhieu lop
SELECT i.firstname || ' ' || i.lastname 
INTO v_name 
FROM instructor i 
WHERE i.instructorid = ( 
    SELECT instructorid FROM class 
    GROUP BY instructorid 
    HAVING COUNT(*) = (
        SELECT MAX(COUNT(*)) FROM class GROUP BY instructorid
    ) 
    FETCH FIRST 1 ROWS ONLY 
); 
INSERT INTO Cau1 (ID, NAME) 
VALUES (Cau1Seq.NEXTVAL, v_name); 
COMMIT; 
DBMS_OUTPUT.PUT_LINE('Hoan tat!'); 
EXCEPTION 
WHEN NO_DATA_FOUND THEN 
    DBMS_OUTPUT.PUT_LINE('Khong tim thay du lieu'); 
    ROLLBACK; 

WHEN OTHERS THEN 
    DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM); 
    ROLLBACK; 
END; 
/

SELECT * FROM Cau1;

-- cau 2

DECLARE 
v_sid NUMBER := &ma_sinh_vien; 
v_fname VARCHAR2(25) := '&ho_sinh_vien'; 
v_lname VARCHAR2(25) := '&ten_sinh_vien'; 
v_addr VARCHAR2(50) := '&dia_chi'; 
v_found VARCHAR2(50); 
v_classes NUMBER; 
BEGIN 
-- Thu tim sinh vien theo ma vua nhap 
SELECT firstname || ' ' || lastname 
INTO v_found 
FROM student 
WHERE studentid = v_sid; 
-- Neu tim thay: dem so lop dang hoc 
SELECT COUNT(*) 
INTO v_classes 
FROM enrollment 
WHERE studentid = v_sid; 
DBMS_OUTPUT.PUT_LINE('Ho ten: ' || v_found); 
DBMS_OUTPUT.PUT_LINE('So lop dang hoc: ' || v_classes); 
EXCEPTION 
WHEN NO_DATA_FOUND THEN 
-- Sinh vien chua ton tai: them moi 
DBMS_OUTPUT.PUT_LINE('Sinh vien chua ton tai. Dang them moi...');
INSERT INTO student (studentid, firstname, lastname, address, registrationdate, createdby, createddate, modifiedby, modifieddate) 
VALUES (v_sid, v_fname, v_lname, v_addr, SYSDATE, USER, SYSDATE, USER, SYSDATE); 
COMMIT; 
DBMS_OUTPUT.PUT_LINE('Da them sinh vien moi: ' || v_fname || ' ' || v_lname); 
END; 
/

-- Bai 2
-- cau 1

DECLARE 
v_instructor_id NUMBER := &ma_giao_vien; 
v_so_lop NUMBER; 
BEGIN 
-- Dem so lop giao vien dang day 
SELECT COUNT(*) 
INTO v_so_lop 
FROM class 
WHERE instructorid = v_instructor_id; 
-- Phan nhanh theo ket qua 
IF v_so_lop >= 5 THEN 
DBMS_OUTPUT.PUT_LINE('Giao vien nay nen nghi ngoi!'); 
ELSE 
DBMS_OUTPUT.PUT_LINE('So lop giao vien dang day: ' || v_so_lop); END IF; 
EXCEPTION 
WHEN NO_DATA_FOUND THEN 
DBMS_OUTPUT.PUT_LINE('Khong tim thay giao vien co ma: ' || 
v_instructor_id); 
END; 
/ 

-- cau 2

DECLARE 
v_sid NUMBER := &ma_sinh_vien; 
v_cid NUMBER := &ma_lop; 
v_score NUMBER; 
v_grade VARCHAR2(2); 
v_check NUMBER; 
BEGIN 
-- Kiem tra sinh vien ton tai 
SELECT COUNT(*) INTO v_check 
FROM student WHERE studentid = v_sid; 
IF v_check = 0 THEN 
DBMS_OUTPUT.PUT_LINE('Loi: Ma sinh vien ' || v_sid || ' khong ton tai!'); 
RETURN; 
END IF; 
-- Kiem tra lop ton tai 
SELECT COUNT(*) INTO v_check 
FROM class WHERE classid = v_cid; 
IF v_check = 0 THEN 
DBMS_OUTPUT.PUT_LINE('Loi: Ma lop ' || v_cid || ' khong ton tai!'); RETURN; 
END IF; 
-- Lay diem cua sinh vien trong lop 
SELECT finalgrade 
INTO v_score 
FROM enrollment 
WHERE studentid = v_sid AND classid = v_cid; 
-- Quy doi diem so sang diem chu bang CASE 
CASE 
WHEN v_score >= 90 THEN v_grade := 'A'; 
WHEN v_score >= 80 THEN v_grade := 'B'; 
WHEN v_score >= 70 THEN v_grade := 'C'; 
WHEN v_score >= 50 THEN v_grade := 'D'; 
ELSE v_grade := 'F'; 
END CASE; 
DBMS_OUTPUT.PUT_LINE('Diem so: ' || v_score || ' -> Diem chu: ' || v_grade); 
EXCEPTION 
WHEN NO_DATA_FOUND THEN 
DBMS_OUTPUT.PUT_LINE('Sinh vien chua dang ky lop nay hoac chua co diem!'); 
END; 
/ 

-- cau 3

DECLARE 
-- Cursor 1: Duyet tung mon hoc 
CURSOR cur_course IS 
SELECT courseno, description 
FROM course 
ORDER BY courseno; 
-- Cursor 2: Lay lop hoc cua mot mon (co doi so) 
CURSOR cur_class (p_courseno NUMBER) IS 
SELECT c.classno, 
COUNT(e.studentid) AS so_sv 
FROM class c 
LEFT JOIN enrollment e ON c.classid = e.classid 
WHERE c.courseno = p_courseno 
GROUP BY c.classno 
ORDER BY c.classno; 
v_courseno course.courseno%TYPE; 
v_desc course.description%TYPE; 
v_classno class.classno%TYPE; 
v_count NUMBER; 
BEGIN 
-- Duyet cursor ngoai: tung mon hoc 
OPEN cur_course; 
LOOP 
FETCH cur_course INTO v_courseno, v_desc; 
EXIT WHEN cur_course%NOTFOUND; 
-- In ten mon hoc 
DBMS_OUTPUT.PUT_LINE(v_courseno || ' ' || v_desc); 
-- Mo cursor trong voi doi so la ma mon hoc hien tai 
OPEN cur_class(v_courseno); 
LOOP 
FETCH cur_class INTO v_classno, v_count; 
EXIT WHEN cur_class%NOTFOUND; 
DBMS_OUTPUT.PUT_LINE('Lop: ' || v_classno || 
' co so luong sinh vien dang ki: ' || 
v_count); 
END LOOP; 
CLOSE cur_class; 
END LOOP; 
CLOSE cur_course; 
EXCEPTION 
WHEN OTHERS THEN 
IF cur_course%ISOPEN THEN CLOSE cur_course; END IF; 
IF cur_class%ISOPEN THEN CLOSE cur_class; END IF; 
DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM); 
END; 
/ 

-- B�i 4
-- cau 4.1a

CREATE OR REPLACE PROCEDURE find_sname 
(i_student_id IN student.studentid%TYPE, 
o_first_name OUT student.firstname%TYPE, 
o_last_name OUT student.lastname%TYPE) 
IS 
BEGIN 
SELECT firstname, lastname 
INTO o_first_name, o_last_name 
FROM student 
WHERE studentid = i_student_id; 
EXCEPTION 
WHEN NO_DATA_FOUND THEN 
o_first_name := NULL; 
o_last_name := NULL; 
DBMS_OUTPUT.PUT_LINE('Khong tim thay sinh vien ID: ' || 
i_student_id); 
END find_sname; 
/

DECLARE
    v_fname VARCHAR2(25);
    v_lname VARCHAR2(25);
BEGIN
    find_sname(5, v_fname, v_lname);
    DBMS_OUTPUT.PUT_LINE(v_fname || ' ' || v_lname);
END;
/
-- cau 4.1b

CREATE OR REPLACE PROCEDURE print_student_name 
(i_student_id IN student.studentid%TYPE) 
IS 
v_first student.firstname%TYPE; 
v_last student.lastname%TYPE; 
BEGIN 
-- Goi thu tuc find_sname da co san 
find_sname(i_student_id, v_first, v_last); 
IF v_first IS NOT NULL OR v_last IS NOT NULL THEN 
DBMS_OUTPUT.PUT_LINE('Ho ten sinh vien: ' || v_first || ' ' || 
v_last); 
END IF; 
END print_student_name; 
/ 
-- Goi thu tuc de kiem tra: 
BEGIN 
print_student_name(5); 
END; 
/
-- cau 4.2
-- th�m 15 sinh vi�n v�o l?p 1 (m�n 1)

INSERT INTO ENROLLMENT VALUES (2,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (3,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (4,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (5,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (6,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (7,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (8,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (9,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (10,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (11,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (12,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (13,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (14,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (15,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);
INSERT INTO ENROLLMENT VALUES (16,1,SYSDATE,80,'admin',SYSDATE,'admin',SYSDATE);

CREATE OR REPLACE PROCEDURE Discount 
IS 
BEGIN 
FOR rec IN ( 
SELECT c.courseno, c.description, c.cost 
FROM course c 
WHERE (SELECT COUNT(*) FROM enrollment e 
JOIN class cl ON e.classid = cl.classid 
WHERE cl.courseno = c.courseno) > 15 
) LOOP 
-- Giam gia 5% 
UPDATE course 
SET cost = cost * 0.95 
WHERE courseno = rec.courseno; 
DBMS_OUTPUT.PUT_LINE('Da giam gia mon hoc: ' || rec.description || ' | Gia cu: ' || rec.cost 
|| ' | Gia moi: ' || ROUND(rec.cost * 0.95, 2)); 
END LOOP; 
COMMIT; 
DBMS_OUTPUT.PUT_LINE('Hoan tat giam gia.'); 
EXCEPTION 
WHEN OTHERS THEN 
ROLLBACK; 
DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM); 
END Discount; 
/ 
-- Goi thu tuc: 
BEGIN Discount;
END; 
/ 

-- cau 4.3

CREATE OR REPLACE FUNCTION Total_cost_for_student 
(p_student_id IN student.studentid%TYPE) 
RETURN NUMBER IS
    v_total NUMBER; 
    v_check NUMBER; 
BEGIN 
-- Kiem tra sinh vien co ton tai khong 
SELECT COUNT(*) INTO v_check 
FROM student WHERE studentid = p_student_id; 
IF v_check = 0 THEN 
RETURN NULL; -- Sinh vien khong ton tai 
END IF; 
-- Tinh tong chi phi: sum(cost cua tung mon da dang ky) 
SELECT NVL(SUM(co.cost), 0) 
INTO v_total 
FROM enrollment e 
JOIN class cl ON e.classid = cl.classid 
JOIN course co ON cl.courseno = co.courseno 
WHERE e.studentid = p_student_id; 
RETURN v_total; 
EXCEPTION 
WHEN OTHERS THEN 
RETURN NULL; 
END Total_cost_for_student; 
/ 
-- Goi ham de kiem tra: 
SELECT Total_cost_for_student(101) AS "Tong chi phi" FROM DUAL; 
-- Hoac trong PL/SQL: 
BEGIN 
DBMS_OUTPUT.PUT_LINE('Tong chi phi: ' || Total_cost_for_student(5)); END; 
/ 

-- B�i 5
-- C�u 5.1
--course
CREATE OR REPLACE TRIGGER trg_course_audit 
BEFORE INSERT OR UPDATE ON course 
FOR EACH ROW 
BEGIN 
IF INSERTING THEN 
:NEW.createdby := USER; 
:NEW.createddate := SYSDATE; 
END IF; 
-- Luon cap nhat modified (ca khi INSERT lan UPDATE) 
:NEW.modifiedby := USER; 
:NEW.modifieddate := SYSDATE; 
END trg_course_audit; 
/ 
-- Class
CREATE OR REPLACE TRIGGER trg_class_audit 
BEFORE INSERT OR UPDATE ON class 
FOR EACH ROW 
BEGIN 
IF INSERTING THEN 
:NEW.createdby := USER; 
:NEW.createddate := SYSDATE; 
END IF; 
:NEW.modifiedby := USER; 
:NEW.modifieddate := SYSDATE; 
END trg_class_audit;
/
-- STUDENT 
CREATE OR REPLACE TRIGGER trg_student_audit 
BEFORE INSERT OR UPDATE ON student 
FOR EACH ROW 
BEGIN 
IF INSERTING THEN 
:NEW.createdby:=USER; 
:NEW.createddate:=SYSDATE; 
END IF; 
:NEW.modifiedby:=USER; 
:NEW.modifieddate:=SYSDATE; 
END trg_student_audit; 
/ 
-- ENROLLMENT 
CREATE OR REPLACE TRIGGER trg_enrollment_audit 
BEFORE INSERT OR UPDATE ON enrollment 
FOR EACH ROW 
BEGIN 
IF INSERTING THEN 
:NEW.createdby:=USER; 
:NEW.createddate:=SYSDATE; 
END IF; 
:NEW.modifiedby:=USER; 
:NEW.modifieddate:=SYSDATE; 
END trg_enrollment_audit;
/ 
-- INSTRUCTOR 
CREATE OR REPLACE TRIGGER trg_instructor_audit 
BEFORE INSERT OR UPDATE ON instructor 
FOR EACH ROW 
BEGIN 
IF INSERTING THEN 
:NEW.createdby:=USER; 
:NEW.createddate:=SYSDATE; 
END IF; 
:NEW.modifiedby:=USER; 
:NEW.modifieddate:=SYSDATE; 
END trg_instructor_audit; 
/ 
-- GRADE 
CREATE OR REPLACE TRIGGER trg_grade_audit 
BEFORE INSERT OR UPDATE ON grade 
FOR EACH ROW 
BEGIN 
IF INSERTING THEN 
:NEW.createdby:=USER; 
:NEW.createddate:=SYSDATE; 
END IF; 
:NEW.modifiedby:=USER; 
:NEW.modifieddate:=SYSDATE; 
END trg_grade_audit;
/ 

--test insert

INSERT INTO course (courseno, description, cost)
VALUES (999, 'Test trigger', 1000);

SELECT courseno, createdby, createddate, modifiedby, modifieddate
FROM course
WHERE courseno = 999;

UPDATE course
SET description = 'Updated trigger'
WHERE courseno = 999;

SELECT createdby, createddate, modifiedby, modifieddate,Description
FROM course
WHERE courseno = 999;

INSERT INTO student (studentid, firstname, lastname, registrationdate)
VALUES (999, 'To�n', 'Tr?n',SYSDATE);

SELECT *
FROM student
WHERE studentid = 999;

-- cau 5.2

INSERT INTO STUDENT 
(StudentID, FirstName, LastName, Address, RegistrationDate, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
VALUES 
(101, 'V?n', 'Quang', 'TP.HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);

INSERT INTO ENROLLMENT 
VALUES (101, 1, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO ENROLLMENT 
VALUES (101, 2, SYSDATE, 85, USER, SYSDATE, USER, SYSDATE);
INSERT INTO ENROLLMENT 
VALUES (101, 3, SYSDATE, 90, USER, SYSDATE, USER, SYSDATE);

CREATE OR REPLACE TRIGGER trg_max_enrollment 
BEFORE INSERT ON enrollment 
FOR EACH ROW 
DECLARE 
v_so_lop NUMBER; 
BEGIN 
-- Dem so lop sinh vien nay dang dang ky 
SELECT COUNT(*) 
INTO v_so_lop 
FROM enrollment 
WHERE studentid = :NEW.studentid; 
-- Neu da co 3 lop tro len thi tu choi 
IF v_so_lop >= 3 THEN 
RAISE_APPLICATION_ERROR( 
-20001, 
'Sinh vien ' || :NEW.studentid || 
' da dang ky du 3 lop! Khong the dang ky them.' 
); 
END IF; 
END trg_max_enrollment; 
/ 
-- Kiem tra trigger: 
-- Sinh vien 101 da co 3 lop, thu them lop thu 4: 
INSERT INTO enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate) 
VALUES (101, 999, SYSDATE, USER, SYSDATE, USER, SYSDATE); 

Show USER;

SET TIMING ON;

-- tang ung dung
SELECT * FROM enrollment;
-- tang luu tru
SELECT studentid, COUNT(*) 
FROM enrollment
GROUP BY studentid;