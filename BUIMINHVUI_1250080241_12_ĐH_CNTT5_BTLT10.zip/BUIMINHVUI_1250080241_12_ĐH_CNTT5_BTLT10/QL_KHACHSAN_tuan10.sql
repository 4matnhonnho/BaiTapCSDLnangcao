CREATE TABLE Phong (
    MaPhong VARCHAR2(10) PRIMARY KEY,
    LoaiPhong VARCHAR2(50),
    TrangThai VARCHAR2(20) CHECK (TrangThai IN ('TRONG','DA_THUE','BAO_TRI')),
    GiaTheoGio NUMBER(10,2),
    GiaTheoNgay NUMBER(10,2),
    SoNguoiToiDa NUMBER(5)
);

CREATE TABLE KhachHang (
    MaKH VARCHAR2(10) PRIMARY KEY,
    HoTen VARCHAR2(100),
    CCCD VARCHAR2(20) UNIQUE,
    SoDT VARCHAR2(15),
    Email VARCHAR2(100),
    QuocTich VARCHAR2(50)
);

CREATE TABLE HoaDon (
    MaHD VARCHAR2(10) PRIMARY KEY,
    MaKH VARCHAR2(10),
    MaPhong VARCHAR2(10),
    NgayNhan DATE,
    NgayTra DATE,
    SoNguoi NUMBER(5),
    TongTien NUMBER(15,2),
    TrangThai VARCHAR2(20) CHECK (TrangThai IN ('CHO_NHAN','DANG_O','DA_TRA','HUY')),

    CONSTRAINT fk_hd_kh FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    CONSTRAINT fk_hd_phong FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong)
);

CREATE TABLE ChiPhiPhuThu (
    MaCP VARCHAR2(10) PRIMARY KEY,
    MaHD VARCHAR2(10),
    MoTa VARCHAR2(200),
    SoTien NUMBER(15,2),
    ThoiGian DATE,

    CONSTRAINT fk_cp_hd FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD)
);

CREATE TABLE LichSuPhong (
    MaLS VARCHAR2(10) PRIMARY KEY,
    MaPhong VARCHAR2(10),
    MaHD VARCHAR2(10),
    NgayNhan DATE,
    NgayTra DATE,
    GhiChu VARCHAR2(200),

    CONSTRAINT fk_ls_phong FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong),
    CONSTRAINT fk_ls_hd FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD)
);

INSERT INTO Phong VALUES ('P10','Don','TRONG',50000,300000,2);
INSERT INTO Phong VALUES ('P11','Doi','TRONG',80000,500000,4);
INSERT INTO Phong VALUES ('P12','Doi','TRONG',80000,500000,4);
INSERT INTO KhachHang 
VALUES ('KH10','Nguyen Van A','123456789','0901','a@gmail.com','VN');

INSERT INTO KhachHang 
VALUES ('KH11','Tran Thi B','987654321','0902','b@gmail.com','VN');
commit;

-- Phieu 3 cau a

CREATE OR REPLACE TRIGGER trg_DatPhong
BEFORE INSERT ON HoaDon
FOR EACH ROW
DECLARE
    v_dem NUMBER;
    v_trangthai VARCHAR2(20);
    v_songuoi NUMBER;
    v_gia NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM KhachHang
    WHERE MaKH = :NEW.MaKH;
    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Khach hang khong ton tai');
    END IF;
    SELECT TrangThai, SoNguoiToiDa, GiaTheoNgay
    INTO v_trangthai, v_songuoi, v_gia
    FROM Phong
    WHERE MaPhong = :NEW.MaPhong;
    IF v_trangthai != 'TRONG' THEN
        RAISE_APPLICATION_ERROR(-20002, 'Phong khong trong');
    END IF;
    IF :NEW.SoNguoi > v_songuoi THEN
        RAISE_APPLICATION_ERROR(-20003, 'Vuot qua so nguoi toi da');
    END IF;
    IF :NEW.NgayNhan >= :NEW.NgayTra THEN
        RAISE_APPLICATION_ERROR(-20004, 'Ngay khong hop le');
    END IF;

    IF :NEW.NgayNhan < TRUNC(SYSDATE) THEN
        RAISE_APPLICATION_ERROR(-20005, 'Ngay nhan phai >= hom nay');
    END IF;
    :NEW.TongTien := ( :NEW.NgayTra - :NEW.NgayNhan ) * v_gia;
    UPDATE Phong
    SET TrangThai = 'DA_THUE'
    WHERE MaPhong = :NEW.MaPhong;
END;
/

-- test
SELECT *
FROM phong;
INSERT INTO HoaDon
VALUES ('HD10','KH10','P10',SYSDATE+1,SYSDATE+3,2,NULL,'CHO_NHAN');

INSERT INTO HoaDon
VALUES ('HD11','KH10','P999',SYSDATE+1,SYSDATE+3,2,NULL,'CHO_NHAN');

INSERT INTO HoaDon
VALUES ('HD12','KH10','P11',SYSDATE+1,SYSDATE+3,10,NULL,'CHO_NHAN');

--Phieu 3 cau c

CREATE OR REPLACE TRIGGER trg_SuaChiPhi
FOR INSERT OR UPDATE ON ChiPhiPhuThu
COMPOUND TRIGGER
    v_count NUMBER := 0;
    BEFORE STATEMENT IS
    BEGIN
        v_count := 0;
    END BEFORE STATEMENT;
    BEFORE EACH ROW IS
    BEGIN
        v_count := v_count + 1;
        IF v_count > 5 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Chi duoc toi da 5 chi phi');
        END IF;
        IF :NEW.SoTien <= 0 OR :NEW.SoTien >= 50000000 THEN
            RAISE_APPLICATION_ERROR(-20002, 'So tien khong hop le');
        END IF;
    END BEFORE EACH ROW;
    AFTER STATEMENT IS
    BEGIN
        UPDATE HoaDon hd
        SET TongTien = NVL(TongTien,0) + (
            SELECT NVL(SUM(SoTien),0)
            FROM ChiPhiPhuThu cp
            WHERE cp.MaHD = hd.MaHD
        );
    END AFTER STATEMENT;
END;
/

-- test
select * from hoadon;
INSERT INTO ChiPhiPhuThu 
VALUES ('CP10','HD10','Nuoc',10000,SYSDATE);

INSERT INTO ChiPhiPhuThu 
VALUES ('CP11','HD10','Do an',20000,SYSDATE);

INSERT INTO ChiPhiPhuThu 
VALUES ('CP12','HD10','Sai',-100,SYSDATE);

-- Phieu 2 c�u d

CREATE OR REPLACE VIEW vw_PhongTrong AS
SELECT 
    MaPhong,
    LoaiPhong,
    GiaTheoNgay,
    SoNguoiToiDa
FROM Phong
WHERE TrangThai = 'TRONG';

-- Phieu 2 cau b

CREATE OR REPLACE TRIGGER trg_CapNhatTrangThaiHD
BEFORE UPDATE OF TrangThai ON HoaDon
FOR EACH ROW
DECLARE
    v_maLS VARCHAR2(10);
BEGIN
    IF :OLD.TrangThai IN ('DA_TRA','HUY') THEN
        RAISE_APPLICATION_ERROR(-20001, 'Khong duoc thay doi trang thai');
    END IF;
    IF :OLD.TrangThai = 'CHO_NHAN' THEN
        IF :NEW.TrangThai NOT IN ('DANG_O','HUY') THEN
            RAISE_APPLICATION_ERROR(-20002, 'Chuyen trang thai khong hop le');
        END IF;
    END IF;
    IF :OLD.TrangThai = 'DANG_O' THEN
        IF :NEW.TrangThai != 'DA_TRA' THEN
            RAISE_APPLICATION_ERROR(-20003, 'Chi duoc chuyen sang DA_TRA');
        END IF;
    END IF;
    IF :NEW.TrangThai = 'DA_TRA' THEN
        UPDATE Phong
        SET TrangThai = 'TRONG'
        WHERE MaPhong = :OLD.MaPhong;
        v_maLS := 'LS' || TO_CHAR(SYSDATE,'HH24MISS');
        INSERT INTO LichSuPhong
        VALUES (v_maLS, :OLD.MaPhong, :OLD.MaHD,
                :OLD.NgayNhan, :OLD.NgayTra, 'Da tra phong');
    END IF;
    IF :NEW.TrangThai = 'HUY' THEN
        UPDATE Phong
        SET TrangThai = 'TRONG'
        WHERE MaPhong = :OLD.MaPhong;
    END IF;
END;
/

-- test
INSERT INTO HoaDon
VALUES ('HD20','KH10','P12',SYSDATE+1,SYSDATE+3,2,NULL,'CHO_NHAN');

SELECT * FROM HOADON;
UPDATE HoaDon
SET TrangThai = 'TRONG'
WHERE MaHD = 'HD20';
UPDATE HoaDon
SET TrangThai = 'DANG_O'
WHERE MaHD = 'HD20';