CREATE TABLE tblChucVu
(
    MaCV   VARCHAR2(10) PRIMARY KEY,
    TenCV  VARCHAR2(20) NOT NULL
);

CREATE TABLE tblNhanVien
(
    MaNV         VARCHAR2(10) PRIMARY KEY,
    MaCV         VARCHAR2(10),
    TenNV        VARCHAR2(30) NOT NULL,
    NgaySinh     DATE,
    LuongCanBan  NUMBER(12,2),
    NgayCong     NUMBER(5),
    PhuCap       NUMBER(12,2),

    CONSTRAINT FK_NV_CV
    FOREIGN KEY (MaCV)
    REFERENCES tblChucVu(MaCV)
);

INSERT INTO tblChucVu VALUES ('CV01', 'Qu?n L�');
INSERT INTO tblChucVu VALUES ('CV02', 'Tr??ng Ph�ng');
INSERT INTO tblChucVu VALUES ('CV03', 'Nh�n Vi�n');
INSERT INTO tblChucVu VALUES ('CV04', 'Th?c T?p');

COMMIT;

INSERT INTO tblNhanVien
VALUES ('NV01','CV01','Nguyen Van A', TO_DATE('01/01/1990','DD/MM/YYYY'),10000000,26,2000000);

INSERT INTO tblNhanVien
VALUES ('NV02','CV03','Tran Thi B', TO_DATE('05/05/1995','DD/MM/YYYY'), 7000000,24,1000000);

INSERT INTO tblNhanVien
VALUES ('NV03','CV02','Le Van C', TO_DATE('10/10/1988','DD/MM/YYYY'),9000000,25,1500000);

COMMIT;

--Phieu2Caua

SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE SP_Them_Nhan_Vien
(
    p_MaNV        IN VARCHAR2,
    p_MaCV        IN VARCHAR2,
    p_TenNV       IN VARCHAR2,
    p_NgaySinh    IN DATE,
    p_LuongCB     IN NUMBER,
    p_NgayCong    IN NUMBER,
    p_PhuCap      IN NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM tblChucVu
    WHERE MaCV = p_MaCV;

    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaCV khong ton tai!');
    ELSE
        INSERT INTO tblNhanVien
        VALUES (p_MaNV, p_MaCV, p_TenNV,
                p_NgaySinh, p_LuongCB,
                p_NgayCong, p_PhuCap);

        COMMIT;

        DBMS_OUTPUT.PUT_LINE('Them nhan vien thanh cong!');
    END IF;
END;
/

--Phieu2caub

CREATE OR REPLACE PROCEDURE SP_CapNhat_Nhan_Vien
(
    p_MaNV        IN VARCHAR2,
    p_MaCV        IN VARCHAR2,
    p_TenNV       IN VARCHAR2,
    p_NgaySinh    IN DATE,
    p_LuongCB     IN NUMBER,
    p_NgayCong    IN NUMBER,
    p_PhuCap      IN NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM tblChucVu
    WHERE MaCV = p_MaCV;

    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaCV khong ton tai!');
    ELSE
        UPDATE tblNhanVien
        SET MaCV = p_MaCV,
            TenNV = p_TenNV,
            NgaySinh = p_NgaySinh,
            LuongCanBan = p_LuongCB,
            NgayCong = p_NgayCong,
            PhuCap = p_PhuCap
        WHERE MaNV = p_MaNV;

        COMMIT;

        DBMS_OUTPUT.PUT_LINE('Cap nhat thanh cong!');
    END IF;
END;
/

--Phieu2cauc

CREATE OR REPLACE PROCEDURE SP_LuongLN
(
    p_MaNV IN VARCHAR2
)
AS
    v_dem   NUMBER := 0;
    v_Luong NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM tblNhanVien
    WHERE MaNV = p_MaNV;

    IF v_dem = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Khong tim thay nhan vien!');
    ELSE
        SELECT (LuongCanBan * NgayCong + PhuCap)
        INTO v_Luong
        FROM tblNhanVien
        WHERE MaNV = p_MaNV;
        DBMS_OUTPUT.PUT_LINE('Luong: ' || v_Luong);
    END IF;

END;
/

BEGIN
    SP_LuongLN('NV06');
END;
/

--Phieu3bai1

CREATE OR REPLACE PROCEDURE sp_them_nhan_vien1
(
    p_MaNV      IN VARCHAR2,
    p_MaCV      IN VARCHAR2,
    p_TenNV     IN VARCHAR2,
    p_NgaySinh  IN DATE,
    p_LuongCB   IN NUMBER,
    p_NgayCong  IN NUMBER,
    p_PhuCap    IN NUMBER,
    p_KetQua    OUT NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM tblChucVu
    WHERE MaCV = p_MaCV;

    IF v_dem = 0 THEN
        p_KetQua := 0;
        RETURN;
    END IF;

    INSERT INTO tblNhanVien
    VALUES (p_MaNV, p_MaCV, p_TenNV,
            p_NgaySinh, p_LuongCB,
            p_NgayCong, p_PhuCap);

    COMMIT;

    p_KetQua := 1;
END;
/

--Phieu3Cau2

CREATE OR REPLACE PROCEDURE sp_them_nhan_vien1
(
    p_MaNV      IN VARCHAR2,
    p_MaCV      IN VARCHAR2,
    p_TenNV     IN VARCHAR2,
    p_NgaySinh  IN DATE,
    p_LuongCB   IN NUMBER,
    p_NgayCong  IN NUMBER,
    p_PhuCap    IN NUMBER,
    p_KetQua    OUT NUMBER
)
AS
    v_demNV NUMBER := 0;
    v_demCV NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_demNV
    FROM tblNhanVien
    WHERE MaNV = p_MaNV;

    IF v_demNV > 0 THEN
        p_KetQua := 0;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_demCV
    FROM tblChucVu
    WHERE MaCV = p_MaCV;

    IF v_demCV = 0 THEN
        p_KetQua := 1;
        RETURN;
    END IF;

    INSERT INTO tblNhanVien
    VALUES (p_MaNV, p_MaCV, p_TenNV, p_NgaySinh, p_LuongCB, p_NgayCong, p_PhuCap);
    COMMIT;
    p_KetQua := 2;
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_nhan_vien1('NV10','CV03','Pham Van D',
        TO_DATE('01/01/1999','DD/MM/YYYY'),6000000,26,800000,v_kq);

    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_them_nhan_vien1('NV10','CV02','Pham Van A',
        TO_DATE('01/01/1998','DD/MM/YYYY'),6500000,25,500000,v_kq);

    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--Phieu3bai3

CREATE OR REPLACE PROCEDURE sp_capnhat_ngaysinh
(
    p_MaNV      IN VARCHAR2,
    p_NgaySinh  IN DATE,
    p_KetQua    OUT NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM tblNhanVien
    WHERE MaNV = p_MaNV;

    IF v_dem = 0 THEN
        p_KetQua := 0;
    ELSE
        UPDATE tblNhanVien
        SET NgaySinh = p_NgaySinh
        WHERE MaNV = p_MaNV;

        COMMIT;

        p_KetQua := 1;
    END IF;
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_capnhat_ngaysinh('NV01',TO_DATE('02/02/1992','DD/MM/YYYY'),v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_capnhat_ngaysinh('NV6',TO_DATE('05/07/1994','DD/MM/YYYY'),v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

select * from tblnhanvien;