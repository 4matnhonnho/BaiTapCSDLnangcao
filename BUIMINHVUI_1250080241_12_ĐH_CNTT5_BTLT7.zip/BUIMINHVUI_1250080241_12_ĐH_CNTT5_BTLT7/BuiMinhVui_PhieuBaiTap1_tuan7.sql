CREATE TABLE KHOA
(
    Makhoa     VARCHAR2(10) PRIMARY KEY,
    Tenkhoa    VARCHAR2(50) NOT NULL,
    Dienthoai  VARCHAR2(12)
);

CREATE TABLE LOP
(
    Malop        VARCHAR2(10) PRIMARY KEY,
    Tenlop       VARCHAR2(30) NOT NULL,
    Khoa         VARCHAR2(50),
    Hedt         VARCHAR2(50),
    Namnhaphoc   NUMBER(4),
    Makhoa       VARCHAR2(10),
    
    CONSTRAINT FK_LOP_KHOA
    FOREIGN KEY (Makhoa)
    REFERENCES KHOA(Makhoa)
);

-- Phieu1Bai1

CREATE OR REPLACE PROCEDURE SP_THEM_KHOA
(
    p_makhoa     IN VARCHAR2,
    p_tenkhoa    IN VARCHAR2,
    p_dienthoai  IN VARCHAR2
)
AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*)
    INTO v_dem
    FROM KHOA
    WHERE Tenkhoa = p_tenkhoa;

    IF v_dem > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten khoa da ton tai!');
    ELSE
        INSERT INTO KHOA(Makhoa, Tenkhoa, Dienthoai)
        VALUES(p_makhoa, p_tenkhoa, p_dienthoai);

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Them khoa thanh cong!');
    END IF;
END;
/

SET SERVEROUTPUT ON;

BEGIN
    SP_THEM_KHOA('K02', 'Cong nghe thong tin', '0901234567');
END;
/

BEGIN
    SP_THEM_KHOA('K02', 'Kinh T?', '0901546251');
END;
/

BEGIN
    SP_THEM_KHOA('K03', 'Kinh T?', '0901546252');
END;
/

--Phieu1Bai2

CREATE OR REPLACE PROCEDURE SP_THEM_LOP
(
    p_malop       IN VARCHAR2,
    p_tenlop      IN VARCHAR2,
    p_khoa        IN VARCHAR2,
    p_hedt        IN VARCHAR2,
    p_namnhaphoc  IN NUMBER,
    p_makhoa      IN VARCHAR2
)
AS
    v_demlop  NUMBER := 0;
    v_demkhoa NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_demlop
    FROM LOP
    WHERE Tenlop = p_tenlop;

    IF v_demlop > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten lop da ton tai!');
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_demkhoa
    FROM KHOA
    WHERE Makhoa = p_makhoa;

    IF v_demkhoa = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ma khoa khong ton tai!');
        RETURN;
    END IF;

    INSERT INTO LOP(Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa)
    VALUES(p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Them lop thanh cong!');
END;
/

-- Phieu1Bai3

CREATE OR REPLACE PROCEDURE SP_THEM_KHOA_B3
(
    p_makhoa     IN VARCHAR2,
    p_tenkhoa    IN VARCHAR2,
    p_dienthoai  IN VARCHAR2,
    p_ketqua     OUT NUMBER
)
AS
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*)
    INTO v_dem
    FROM KHOA
    WHERE Tenkhoa = p_tenkhoa;

    IF v_dem > 0 THEN
        p_ketqua := 0;
    ELSE
        INSERT INTO KHOA(Makhoa, Tenkhoa, Dienthoai)
        VALUES(p_makhoa, p_tenkhoa, p_dienthoai);

        COMMIT;
        p_ketqua := 1;
    END IF;
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    SP_THEM_KHOA_B3('K03', 'K? to�n', '0911111111', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    SP_THEM_KHOA_B3('K03', 'K? to�n', '0911111111', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    SP_THEM_KHOA_B3('K06', 'Kinh Doanh', '0954222511', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

--Phieu1Bai4

CREATE OR REPLACE PROCEDURE SP_THEM_LOP2
(
    p_malop       IN VARCHAR2,
    p_tenlop      IN VARCHAR2,
    p_khoa        IN VARCHAR2,
    p_hedt        IN VARCHAR2,
    p_namnhaphoc  IN NUMBER,
    p_makhoa      IN VARCHAR2,
    p_ketqua      OUT NUMBER
)
AS
    v_demlop  NUMBER := 0;
    v_demkhoa NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_demlop
    FROM LOP
    WHERE Tenlop = p_tenlop;

    IF v_demlop > 0 THEN
        p_ketqua := 0;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_demkhoa
    FROM KHOA
    WHERE Makhoa = p_makhoa;

    IF v_demkhoa = 0 THEN
        p_ketqua := 1;
        RETURN;
    END IF;

    INSERT INTO LOP(Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa)
    VALUES(p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);

    COMMIT;

    p_ketqua := 2;
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    SP_THEM_LOP2('L01', 'CNTT1', 'Khoa 1', 'Chinh quy', 2024, 'K01', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    SP_THEM_LOP2('L02', 'CNTT1', 'Khoa 1', 'Chinh quy', 2024, 'K01', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    SP_THEM_LOP2('L03', 'CNTT2', 'Khoa 2', 'Chinh quy', 2024, 'K09', v_kq);
    DBMS_OUTPUT.PUT_LINE('Ket qua: ' || v_kq);
END;
/
